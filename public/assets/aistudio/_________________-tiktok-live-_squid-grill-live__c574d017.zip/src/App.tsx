import { useEffect, useRef, useState, useCallback } from 'react';
import {
  CustomerOrder,
  HelperContributor,
  LeaderboardEntry,
  LiveEventNotification,
  LiveStats,
  TikTokStatus,
  GrillSlot,
} from './types/game';
import { soundManager } from './services/sound';
import { SquidStallScene } from './components/SquidStallScene';
import { TopHUDLeaderboard } from './components/TopHUDLeaderboard';
import { TikTokConnectModal } from './components/TikTokConnectModal';
import { LiveSummaryModal } from './components/LiveSummaryModal';
import { OrderNotificationAlert } from './components/OrderNotificationAlert';
import { StreamerControlDock } from './components/StreamerControlDock';

const PRICE_PER_SKEWER_BAHT = 20;

// Sample cute avatars for demo and fallback
const RANDOM_AVATARS = [
  'https://api.dicebear.com/7.x/bottts/svg?seed=NongSquid',
  'https://api.dicebear.com/7.x/bottts/svg?seed=PeeMoo',
  'https://api.dicebear.com/7.x/bottts/svg?seed=NekoChef',
  'https://api.dicebear.com/7.x/bottts/svg?seed=SunnyBao',
  'https://api.dicebear.com/7.x/bottts/svg?seed=CuteDino',
  'https://api.dicebear.com/7.x/bottts/svg?seed=PeeChai',
];

const RANDOM_NAMES = [
  'น้องมุกกี้สายเปย์',
  'บอสใหญ่คลองสาน',
  'พี่ต้อมปลาหมึกสด',
  'หมูหวานน่ารัก',
  'เจ๊แอนนาช็อปแหลก',
  'ก้องเกียรติคนดี',
  'น้องพลอยดาวติ๊กต๊อก',
];

export default function App() {
  // 4 Interactive Grill Slots on the Charcoal Grill
  const [grillSlots, setGrillSlots] = useState<GrillSlot[]>([
    { id: 1, isOccupied: true, doneness: 85, status: 'grilling', flipState: 0, cookSpeed: 10 },
    { id: 2, isOccupied: true, doneness: 50, status: 'grilling', flipState: 0, cookSpeed: 10 },
    { id: 3, isOccupied: true, doneness: 20, status: 'grilling', flipState: 0, cookSpeed: 10 },
    { id: 4, isOccupied: true, doneness: 95, status: 'grilling', flipState: 0, cookSpeed: 10 },
  ]);

  // Inventory & Tray Counts
  const [rawSquidStock, setRawSquidStock] = useState<number>(20);
  const [cookedSquidTrayCount, setCookedSquidTrayCount] = useState<number>(4);

  // Orders & Helpers state
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [helpers, setHelpers] = useState<HelperContributor[]>([]);
  const [notifications, setNotifications] = useState<LiveEventNotification[]>([]);

  // Overall Live Session Statistics
  const [stats, setStats] = useState<LiveStats>({
    totalOrdersReceived: 0,
    totalSkewersOrdered: 0,
    totalSkewersGrilled: 4,
    totalSkewersServed: 0,
    totalLikesReceived: 0,
    totalRevenueEstimate: 0,
    rawSquidStock: 20,
    cookedSquidTrayCount: 4,
    streamStartTime: Date.now(),
    uniqueCustomersCount: 0,
    uniqueHelpersCount: 0,
    giftBreakdown: {},
  });

  // Leaderboard lists
  const [topBuyers, setTopBuyers] = useState<LeaderboardEntry[]>([]);
  const [topHelpers, setTopHelpers] = useState<LeaderboardEntry[]>([]);

  // TikTok Live Connection Status
  const [tiktokStatus, setTiktokStatus] = useState<TikTokStatus>({
    status: 'disconnected',
    username: '',
  });

  // UI States
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
  const [isGrillingFast, setIsGrillingFast] = useState(false);
  const [isAutoSimulating, setIsAutoSimulating] = useState(false);

  // Audio toggles
  const [isBgmOn, setIsBgmOn] = useState(false);
  const [isTtsOn, setIsTtsOn] = useState(true);
  const [isMuted, setIsMuted] = useState(false);

  // Timers
  const autoSimTimerRef = useRef<any>(null);
  const cookingLoopRef = useRef<any>(null);

  // Add toast notification
  const addNotification = useCallback(
    (notif: Omit<LiveEventNotification, 'id' | 'timestamp'>) => {
      const newNotif: LiveEventNotification = {
        ...notif,
        id: Math.random().toString(36).substring(2, 9),
        timestamp: Date.now(),
      };
      setNotifications((prev) => [newNotif, ...prev.slice(0, 3)]);

      setTimeout(() => {
        setNotifications((prev) => prev.filter((n) => n.id !== newNotif.id));
      }, 4000);
    },
    []
  );

  // 1. Interactive Cooking & Auto-Refill Grill Loop
  useEffect(() => {
    soundManager.startGrillSizzle();

    cookingLoopRef.current = setInterval(() => {
      setGrillSlots((prevSlots) => {
        return prevSlots.map((slot) => {
          if (!slot.isOccupied) return slot;

          if (slot.doneness < 100) {
            const increment = isGrillingFast ? 14 : 7;
            const newDoneness = Math.min(100, slot.doneness + increment);
            const isNowCooked = newDoneness >= 100;

            if (isNowCooked && slot.status !== 'cooked') {
              soundManager.playCookedDing();
            }

            return {
              ...slot,
              doneness: newDoneness,
              status: isNowCooked ? 'cooked' : 'grilling',
            };
          }

          return slot;
        });
      });
    }, 1000);

    return () => {
      if (cookingLoopRef.current) clearInterval(cookingLoopRef.current);
      soundManager.stopGrillSizzle();
    };
  }, [isGrillingFast]);

  // Pick up single cooked skewer from grill to finished tray
  const handlePickUpCookedSkewer = (slotId: number) => {
    soundManager.playFlipSound();

    setCookedSquidTrayCount((prev) => prev + 1);
    setStats((prev) => ({
      ...prev,
      totalSkewersGrilled: prev.totalSkewersGrilled + 1,
      cookedSquidTrayCount: prev.cookedSquidTrayCount + 1,
    }));

    // Free the slot, and if rawSquidStock > 0, auto-fill with a new raw skewer!
    setGrillSlots((prev) =>
      prev.map((slot) => {
        if (slot.id === slotId) {
          if (rawSquidStock > 0) {
            setRawSquidStock((r) => Math.max(0, r - 1));
            return {
              ...slot,
              isOccupied: true,
              doneness: 0,
              status: 'raw',
            };
          } else {
            return {
              ...slot,
              isOccupied: false,
              doneness: 0,
              status: 'empty',
            };
          }
        }
        return slot;
      })
    );
  };

  // Pick up all cooked skewers from grill to finished tray
  const handlePickUpAllCooked = () => {
    soundManager.playFlipSound();

    let cookedCount = 0;
    setGrillSlots((prev) => {
      return prev.map((slot) => {
        if (slot.isOccupied && slot.status === 'cooked') {
          cookedCount++;
          if (rawSquidStock > 0) {
            setRawSquidStock((r) => Math.max(0, r - 1));
            return {
              ...slot,
              isOccupied: true,
              doneness: 0,
              status: 'raw',
            };
          } else {
            return {
              ...slot,
              isOccupied: false,
              doneness: 0,
              status: 'empty',
            };
          }
        }
        return slot;
      });
    });

    if (cookedCount > 0) {
      setCookedSquidTrayCount((prev) => prev + cookedCount);
      setStats((prev) => ({
        ...prev,
        totalSkewersGrilled: prev.totalSkewersGrilled + cookedCount,
        cookedSquidTrayCount: prev.cookedSquidTrayCount + cookedCount,
      }));
    }
  };

  // Refill raw squids box
  const handleRefillRawSquids = () => {
    soundManager.playLadleSauce();
    setRawSquidStock((prev) => prev + 10);
    // Also fill any empty slots on grill
    setGrillSlots((prev) =>
      prev.map((slot) => {
        if (!slot.isOccupied) {
          return {
            ...slot,
            isOccupied: true,
            doneness: 0,
            status: 'raw',
          };
        }
        return slot;
      })
    );
  };

  // Plate 1 skewer onto customer plate
  const handlePlateOneSkewer = () => {
    if (cookedSquidTrayCount <= 0) return;

    const waitingOrder = orders.find((o) => o.status === 'waiting' || o.status === 'plating');
    if (!waitingOrder) return;

    soundManager.playLadleSauce();
    setCookedSquidTrayCount((prev) => Math.max(0, prev - 1));

    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === waitingOrder.id) {
          const nextPlated = (order.platedSkewers || 0) + 1;
          return {
            ...order,
            status: 'plating',
            platedSkewers: nextPlated,
          };
        }
        return order;
      })
    );
  };

  // Plate all needed skewers for current order
  const handlePlateAllForCurrentOrder = () => {
    if (cookedSquidTrayCount <= 0) return;

    const waitingOrder = orders.find((o) => o.status === 'waiting' || o.status === 'plating');
    if (!waitingOrder) return;

    const needed = waitingOrder.skewers - (waitingOrder.platedSkewers || 0);
    const toPlate = Math.min(needed, cookedSquidTrayCount);

    soundManager.playLadleSauce();
    setCookedSquidTrayCount((prev) => Math.max(0, prev - toPlate));

    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === waitingOrder.id) {
          const nextPlated = (order.platedSkewers || 0) + toPlate;
          return {
            ...order,
            status: 'plating',
            platedSkewers: nextPlated,
          };
        }
        return order;
      })
    );
  };

  // Serve plate to customer!
  const handleServeCurrentCustomer = () => {
    const waitingOrder = orders.find((o) => o.status === 'waiting' || o.status === 'plating');
    if (!waitingOrder) return;

    soundManager.playServeSound();

    const servedCount = waitingOrder.platedSkewers || waitingOrder.skewers;
    const addedRevenue = servedCount * PRICE_PER_SKEWER_BAHT;

    // Update orders
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === waitingOrder.id) {
          return {
            ...order,
            status: 'served',
            servedSkewers: servedCount,
          };
        }
        return order;
      })
    );

    // Update stats
    setStats((prev) => ({
      ...prev,
      totalSkewersServed: prev.totalSkewersServed + servedCount,
      totalRevenueEstimate: prev.totalRevenueEstimate + addedRevenue,
    }));

    // Thai TTS
    soundManager.speakThai(
      `เสิร์ฟปลาหมึกย่างให้คุณ ${waitingOrder.nickname} เรียบร้อยแล้วจ้า ขอบคุณมากครับ!`
    );

    // Toast
    addNotification({
      type: 'order',
      title: `เสิร์ฟปลาหมึกให้คุณ ${waitingOrder.nickname}!`,
      description: `เสิร์ฟครบ ${servedCount} ไม้ อร่อยแซ่บ! (+${addedRevenue}฿)`,
      avatar: waitingOrder.profilePictureUrl,
      badge: '✨',
    });
  };

  // 2. Handle New Customer Order from TikTok Live
  const handleOrderAction = useCallback(
    (data: {
      skewers: number;
      giftName: string;
      nickname: string;
      uniqueId: string;
      profilePictureUrl: string;
      diamonds?: number;
      isRandom?: boolean;
    }) => {
      const orderId = Math.random().toString(36).substring(2, 9);
      const newOrder: CustomerOrder = {
        id: orderId,
        uniqueId: data.uniqueId || 'viewer',
        nickname: data.nickname || 'ลูกค้า',
        profilePictureUrl:
          data.profilePictureUrl ||
          RANDOM_AVATARS[Math.floor(Math.random() * RANDOM_AVATARS.length)],
        skewers: data.skewers || 1,
        giftName: data.giftName || 'ของขวัญ 🎁',
        diamonds: data.diamonds || 1,
        timestamp: Date.now(),
        status: 'waiting',
        platedSkewers: 0,
        servedSkewers: 0,
        isRandom: data.isRandom,
      };

      setOrders((prev) => [...prev, newOrder]);

      setStats((prev) => {
        const newTotalOrdered = prev.totalSkewersOrdered + newOrder.skewers;
        return {
          ...prev,
          totalOrdersReceived: prev.totalOrdersReceived + 1,
          totalSkewersOrdered: newTotalOrdered,
          giftBreakdown: {
            ...prev.giftBreakdown,
            [newOrder.giftName]: (prev.giftBreakdown[newOrder.giftName] || 0) + 1,
          },
        };
      });

      // Update Top Buyers Leaderboard
      setTopBuyers((prev) => {
        const existing = prev.find((e) => e.uniqueId === newOrder.uniqueId);
        let updated: LeaderboardEntry[];
        if (existing) {
          updated = prev.map((e) =>
            e.uniqueId === newOrder.uniqueId
              ? {
                  ...e,
                  nickname: newOrder.nickname,
                  profilePictureUrl: newOrder.profilePictureUrl,
                  totalQuantity: e.totalQuantity + newOrder.skewers,
                  lastActive: Date.now(),
                }
              : e
          );
        } else {
          updated = [
            ...prev,
            {
              uniqueId: newOrder.uniqueId,
              nickname: newOrder.nickname,
              profilePictureUrl: newOrder.profilePictureUrl,
              totalQuantity: newOrder.skewers,
              lastActive: Date.now(),
            },
          ];
        }
        return updated.sort((a, b) => b.totalQuantity - a.totalQuantity);
      });

      soundManager.playOrderBell();
      soundManager.triggerVibration([100, 50, 100]);

      const phrase = newOrder.isRandom
        ? `คุณ ${newOrder.nickname} สุ่มแจ็คพอตหมวกหนวด ได้ปลาหมึกย่าง ${newOrder.skewers} ไม้ สุดยอดไปเลย!`
        : `คุณ ${newOrder.nickname} สั่งปลาหมึกย่าง ${newOrder.skewers} ไม้ ขอบคุณมากครับ!`;
      soundManager.speakThai(phrase);

      addNotification({
        type: 'order',
        title: `คุณ ${newOrder.nickname} สั่งปลาหมึก!`,
        description: `สั่ง ${newOrder.skewers} ไม้ (${newOrder.giftName})`,
        avatar: newOrder.profilePictureUrl,
        badge: '🦑',
      });
    },
    [addNotification]
  );

  // 3. Handle Helper Action (Very Good, Dino, Mishka Bear, 100 Likes)
  const handleHelperAction = useCallback(
    (data: {
      grillCount: number;
      giftName?: string;
      nickname: string;
      uniqueId: string;
      profilePictureUrl: string;
      description?: string;
    }) => {
      const helperId = Math.random().toString(36).substring(2, 9);
      const newHelper: HelperContributor = {
        id: helperId,
        uniqueId: data.uniqueId || 'helper',
        nickname: data.nickname || 'เชฟช่วยย่าง',
        profilePictureUrl:
          data.profilePictureUrl ||
          RANDOM_AVATARS[Math.floor(Math.random() * RANDOM_AVATARS.length)],
        grilledCount: data.grillCount || 1,
        giftName: data.giftName || data.description || 'ช่วยย่าง',
        timestamp: Date.now(),
      };

      setHelpers((prev) => [newHelper, ...prev.slice(0, 9)]);

      // Accelerate grill speed
      setIsGrillingFast(true);
      setTimeout(() => setIsGrillingFast(false), 6000);

      // Directly add helper skewers to finished cooked tray!
      setCookedSquidTrayCount((prev) => prev + newHelper.grilledCount);
      setStats((prev) => ({
        ...prev,
        totalSkewersGrilled: prev.totalSkewersGrilled + newHelper.grilledCount,
      }));

      // Update Top Helpers Leaderboard
      setTopHelpers((prev) => {
        const existing = prev.find((e) => e.uniqueId === newHelper.uniqueId);
        let updated: LeaderboardEntry[];
        if (existing) {
          updated = prev.map((e) =>
            e.uniqueId === newHelper.uniqueId
              ? {
                  ...e,
                  nickname: newHelper.nickname,
                  profilePictureUrl: newHelper.profilePictureUrl,
                  totalQuantity: e.totalQuantity + newHelper.grilledCount,
                  lastActive: Date.now(),
                }
              : e
          );
        } else {
          updated = [
            ...prev,
            {
              uniqueId: newHelper.uniqueId,
              nickname: newHelper.nickname,
              profilePictureUrl: newHelper.profilePictureUrl,
              totalQuantity: newHelper.grilledCount,
              lastActive: Date.now(),
            },
          ];
        }
        return updated.sort((a, b) => b.totalQuantity - a.totalQuantity);
      });

      soundManager.playHelperCheer();
      soundManager.speakThai(
        `คุณ ${newHelper.nickname} ส่ง ${newHelper.giftName} ช่วยย่าง ${newHelper.grilledCount} ไม้ ขอบคุณมากครับ!`
      );

      addNotification({
        type: 'helper',
        title: `เชฟ ${newHelper.nickname} มาช่วยย่าง!`,
        description: `ช่วยย่างเพิ่ม ${newHelper.grilledCount} ไม้ (${newHelper.giftName})`,
        avatar: newHelper.profilePictureUrl,
        badge: '🔥',
      });
    },
    [addNotification]
  );

  // 4. SSE Stream connection
  useEffect(() => {
    let eventSource: EventSource | null = null;
    try {
      eventSource = new EventSource('/api/tiktok/events');

      eventSource.onmessage = (event) => {
        try {
          const parsed = JSON.parse(event.data);
          if (parsed.type === 'status') {
            setTiktokStatus({
              status: parsed.data.status,
              username: parsed.data.username,
              roomInfo: parsed.data.roomInfo,
              error: parsed.data.error,
            });
          } else if (parsed.type === 'order_action') {
            handleOrderAction(parsed.data);
          } else if (parsed.type === 'helper_action') {
            handleHelperAction(parsed.data);
          } else if (parsed.type === 'like_pulse') {
            setStats((prev) => ({
              ...prev,
              totalLikesReceived: prev.totalLikesReceived + (parsed.data.likeCount || 1),
            }));
          }
        } catch (e) {
          console.warn('SSE message parse error', e);
        }
      };
    } catch (e) {
      console.warn('EventSource error', e);
    }

    return () => {
      if (eventSource) eventSource.close();
    };
  }, [handleOrderAction, handleHelperAction]);

  // 5. Auto Simulator for practice / preview before going live
  useEffect(() => {
    if (isAutoSimulating) {
      const simulateEvent = () => {
        const isHelper = Math.random() < 0.35;
        const randomName = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];
        const randomAvatar = RANDOM_AVATARS[Math.floor(Math.random() * RANDOM_AVATARS.length)];

        if (isHelper) {
          const helperTypes = [
            { type: 'very good', count: 2, label: 'เยี่ยมสุดๆ 👍' },
            { type: 'mini dino', count: 20, label: 'ไดโนเสาร์จิ๋ว 🦖' },
            { type: 'mishka bear', count: 100, label: 'หมีมีชคา 🐻' },
          ];
          const choice = helperTypes[Math.floor(Math.random() * helperTypes.length)];
          handleHelperAction({
            grillCount: choice.count,
            giftName: choice.label,
            nickname: randomName,
            uniqueId: randomName.toLowerCase().replace(/\s+/g, '_'),
            profilePictureUrl: randomAvatar,
          });
        } else {
          const orderTypes = [
            { gift: 'rose', skewers: 1, label: 'ดอกกุหลาบ 🌹' },
            { gift: 'finger heart', skewers: 5, label: 'หัวใจนิ้ว 🫰' },
            { gift: 'perfume', skewers: 10, label: 'น้ำหอม 🧴' },
            { gift: 'doughnut', skewers: 20, label: 'โดนัท 🍩' },
            {
              gift: 'cap and mustache',
              skewers: Math.floor(Math.random() * 81) + 20,
              label: 'หมวกกับหนวด 🎩🥸 (สุ่มแจ็คพอต!)',
              isRandom: true,
            },
          ];
          const choice = orderTypes[Math.floor(Math.random() * orderTypes.length)];
          handleOrderAction({
            skewers: choice.skewers,
            giftName: choice.label,
            nickname: randomName,
            uniqueId: randomName.toLowerCase().replace(/\s+/g, '_'),
            profilePictureUrl: randomAvatar,
            isRandom: choice.isRandom,
          });
        }
      };

      autoSimTimerRef.current = setInterval(simulateEvent, 6000);
    } else {
      if (autoSimTimerRef.current) {
        clearInterval(autoSimTimerRef.current);
        autoSimTimerRef.current = null;
      }
    }

    return () => {
      if (autoSimTimerRef.current) clearInterval(autoSimTimerRef.current);
    };
  }, [isAutoSimulating, handleOrderAction, handleHelperAction]);

  // Connect to TikTok Live
  const handleConnectTikTok = async (username: string) => {
    const res = await fetch('/api/tiktok/connect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username }),
    });
    const json = await res.json();
    if (!res.ok) {
      throw new Error(json.error || 'เชื่อมต่อ TikTok Live ไม่สำเร็จ');
    }
  };

  // Disconnect from TikTok Live
  const handleDisconnectTikTok = async () => {
    await fetch('/api/tiktok/disconnect', { method: 'POST' });
    setTiktokStatus({ status: 'disconnected', username: '' });
  };

  // Trigger simulated gift
  const handleSimulate = async (data: any) => {
    await fetch('/api/tiktok/simulate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  };

  // Reset live session
  const handleResetSession = () => {
    setOrders([]);
    setHelpers([]);
    setTopBuyers([]);
    setTopHelpers([]);
    setCookedSquidTrayCount(4);
    setRawSquidStock(20);
    setStats({
      totalOrdersReceived: 0,
      totalSkewersOrdered: 0,
      totalSkewersGrilled: 4,
      totalSkewersServed: 0,
      totalLikesReceived: 0,
      totalRevenueEstimate: 0,
      rawSquidStock: 20,
      cookedSquidTrayCount: 4,
      streamStartTime: Date.now(),
      uniqueCustomersCount: 0,
      uniqueHelpersCount: 0,
      giftBreakdown: {},
    });
  };

  // Audio toggles
  const handleToggleBgm = () => {
    const next = !isBgmOn;
    setIsBgmOn(next);
    soundManager.toggleBgm(next);
  };

  const handleToggleTts = () => {
    const next = !isTtsOn;
    setIsTtsOn(next);
    soundManager.setTtsEnabled(next);
  };

  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    soundManager.setMuted(next);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Prompt']">
      {/* 1. Top Bar Contract */}
      <header className="h-16 px-4 sm:px-6 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-8 shrink-0 sticky top-0 z-30 backdrop-blur-md">
        <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
          <span className="text-2xl animate-pulse">🏮</span>
          <span className="text-base sm:text-lg font-black tracking-tight text-white font-['Mali']">
            เทศกาลปลาหมึกย่างโบราณ TikTok Live
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
          <button
            onClick={() => setIsConnectModalOpen(true)}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                tiktokStatus.status === 'connected' ? 'bg-emerald-400' : 'bg-pink-500'
              }`}
            />
            <span>
              {tiktokStatus.status === 'connected'
                ? `@${tiktokStatus.username} (สด)`
                : 'เชื่อมต่อ TikTok'}
            </span>
          </button>
          <button
            onClick={() => setIsSummaryModalOpen(true)}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            สรุปยอดปิดไลฟ์
          </button>
          <span className="text-slate-500 font-mono">
            ไม้ละ {PRICE_PER_SKEWER_BAHT}฿
          </span>
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setIsConnectModalOpen(true)}
            className="px-4 py-2 text-xs font-bold text-stone-950 bg-gradient-to-r from-amber-400 to-orange-400 hover:from-amber-300 hover:to-orange-300 rounded-xl transition-all shadow-md whitespace-nowrap shrink-0 font-['Prompt']"
          >
            {tiktokStatus.status === 'connected' ? '⚙️ จัดการไลฟ์ & ทดสอบ' : '🔗 เชื่อมต่อ Live'}
          </button>
        </div>
      </header>

      {/* 2. Main Live Playfield & Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 flex flex-col gap-4">
        {/* Top 3 HUD Leaderboard */}
        <TopHUDLeaderboard
          topBuyers={topBuyers}
          topHelpers={topHelpers}
          totalOrdered={stats.totalSkewersOrdered}
          totalGrilled={stats.totalSkewersGrilled}
          readyWarmSkewers={cookedSquidTrayCount}
          totalRevenueEstimate={stats.totalRevenueEstimate}
        />

        {/* Festival Interactive Squid Stall Scene */}
        <SquidStallScene
          orders={orders}
          activeHelpers={helpers}
          grillSlots={grillSlots}
          rawSquidStock={rawSquidStock}
          cookedSquidTrayCount={cookedSquidTrayCount}
          totalServed={stats.totalSkewersServed}
          isGrillingFast={isGrillingFast}
          onPickUpCookedSkewer={handlePickUpCookedSkewer}
          onPickUpAllCooked={handlePickUpAllCooked}
          onPlateOneSkewer={handlePlateOneSkewer}
          onPlateAllForCurrentOrder={handlePlateAllForCurrentOrder}
          onServeCurrentCustomer={handleServeCurrentCustomer}
          onRefillRawSquids={handleRefillRawSquids}
        />
      </main>

      {/* 3. Floating Toast Notifications */}
      <OrderNotificationAlert notifications={notifications} />

      {/* 4. Streamer Bottom Dock Controls */}
      <StreamerControlDock
        status={tiktokStatus}
        onOpenConnectModal={() => setIsConnectModalOpen(true)}
        onOpenSummaryModal={() => setIsSummaryModalOpen(true)}
        onSimulateGift={(giftType, count) =>
          handleSimulate({
            giftType,
            count: count || 1,
            nickname: RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)],
            profilePictureUrl: RANDOM_AVATARS[Math.floor(Math.random() * RANDOM_AVATARS.length)],
          })
        }
        onSimulateLike={(count) =>
          handleSimulate({
            isLike: true,
            count: count || 100,
            nickname: 'ผู้ชมสายเคาะใจ',
            profilePictureUrl: RANDOM_AVATARS[0],
          })
        }
        isBgmOn={isBgmOn}
        onToggleBgm={handleToggleBgm}
        isTtsOn={isTtsOn}
        onToggleTts={handleToggleTts}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      {/* 5. Modals */}
      <TikTokConnectModal
        isOpen={isConnectModalOpen}
        onClose={() => setIsConnectModalOpen(false)}
        status={tiktokStatus}
        onConnect={handleConnectTikTok}
        onDisconnect={handleDisconnectTikTok}
        onSimulate={handleSimulate}
        isAutoSimulating={isAutoSimulating}
        onToggleAutoSimulate={() => setIsAutoSimulating((prev) => !prev)}
      />

      <LiveSummaryModal
        isOpen={isSummaryModalOpen}
        onClose={() => setIsSummaryModalOpen(false)}
        stats={stats}
        topBuyer={topBuyers[0] || null}
        topHelper={topHelpers[0] || null}
        onResetSession={handleResetSession}
      />
    </div>
  );
}
