export interface GrillSlot {
  id: number;
  isOccupied: boolean;
  doneness: number; // 0 to 100%
  status: 'empty' | 'raw' | 'grilling' | 'cooked';
  flipState: number;
  cookSpeed: number; // rate of cooking
}

export interface CustomerOrder {
  id: string;
  uniqueId: string;
  nickname: string;
  profilePictureUrl: string;
  skewers: number;
  giftName: string;
  diamonds: number;
  timestamp: number;
  status: 'waiting' | 'plating' | 'served';
  platedSkewers: number;
  servedSkewers: number;
  isRandom?: boolean;
}

export interface HelperContributor {
  id: string;
  uniqueId: string;
  nickname: string;
  profilePictureUrl: string;
  grilledCount: number;
  giftName: string;
  timestamp: number;
}

export interface LeaderboardEntry {
  uniqueId: string;
  nickname: string;
  profilePictureUrl: string;
  totalQuantity: number;
  lastActive: number;
}

export interface LiveStats {
  totalOrdersReceived: number;
  totalSkewersOrdered: number;
  totalSkewersGrilled: number;
  totalSkewersServed: number;
  totalLikesReceived: number;
  totalRevenueEstimate: number; // in Baht (20 Baht per skewer)
  rawSquidStock: number; // in prep box
  cookedSquidTrayCount: number; // on finished tray
  streamStartTime: number;
  uniqueCustomersCount: number;
  uniqueHelpersCount: number;
  giftBreakdown: { [giftName: string]: number };
}

export interface TikTokStatus {
  status: 'disconnected' | 'connecting' | 'connected' | 'error';
  username: string;
  roomInfo?: any;
  error?: string;
}

export interface LiveEventNotification {
  id: string;
  type: 'order' | 'helper' | 'like' | 'system';
  title: string;
  description: string;
  avatar: string;
  badge?: string;
  highlight?: boolean;
  timestamp: number;
}
