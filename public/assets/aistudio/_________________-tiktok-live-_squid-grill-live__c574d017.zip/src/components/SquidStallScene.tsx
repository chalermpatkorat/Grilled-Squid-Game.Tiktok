import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { CustomerOrder, HelperContributor, GrillSlot } from '../types/game';

interface SquidStallSceneProps {
  orders: CustomerOrder[];
  activeHelpers: HelperContributor[];
  grillSlots: GrillSlot[];
  rawSquidStock: number;
  cookedSquidTrayCount: number;
  totalServed: number;
  isGrillingFast: boolean;
  onPickUpCookedSkewer: (slotId: number) => void;
  onPickUpAllCooked: () => void;
  onPlateOneSkewer: () => void;
  onPlateAllForCurrentOrder: () => void;
  onServeCurrentCustomer: () => void;
  onRefillRawSquids: () => void;
}

export const SquidStallScene: React.FC<SquidStallSceneProps> = ({
  orders,
  activeHelpers,
  grillSlots,
  rawSquidStock,
  cookedSquidTrayCount,
  totalServed,
  isGrillingFast,
  onPickUpCookedSkewer,
  onPickUpAllCooked,
  onPlateOneSkewer,
  onPlateAllForCurrentOrder,
  onServeCurrentCustomer,
  onRefillRawSquids,
}) => {
  // Drag and drop states
  const [draggedSlotId, setDraggedSlotId] = useState<number | null>(null);
  const [isTrayHovered, setIsTrayHovered] = useState(false);
  const [isPlateHovered, setIsPlateHovered] = useState(false);
  const [sauceLadleAngle, setSauceLadleAngle] = useState(0);

  // Current customer at the front counter
  const currentOrder = orders.find((o) => o.status === 'waiting' || o.status === 'plating');
  const activeHelper = activeHelpers[0];

  const anyCookedOnGrill = grillSlots.some((s) => s.isOccupied && s.status === 'cooked');
  const neededForCurrent = currentOrder ? currentOrder.skewers - (currentOrder.platedSkewers || 0) : 0;
  const isPlateReadyToServe = currentOrder && (currentOrder.platedSkewers || 0) >= currentOrder.skewers;

  // Handle Drag Start from Grill Slot
  const handleDragStart = (e: React.DragEvent, slot: GrillSlot) => {
    if (slot.status !== 'cooked') {
      e.preventDefault();
      return;
    }
    setDraggedSlotId(slot.id);
    e.dataTransfer.setData('text/plain', slot.id.toString());
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragEnd = () => {
    setDraggedSlotId(null);
    setIsTrayHovered(false);
    setIsPlateHovered(false);
  };

  // Handle Drop on Finished Display Tray
  const handleDropOnTray = (e: React.DragEvent) => {
    e.preventDefault();
    setIsTrayHovered(false);
    const slotIdStr = e.dataTransfer.getData('text/plain');
    const slotId = parseInt(slotIdStr, 10);
    if (!isNaN(slotId)) {
      onPickUpCookedSkewer(slotId);
    }
    setDraggedSlotId(null);
  };

  // Handle Drop on Customer Serving Plate
  const handleDropOnPlate = (e: React.DragEvent) => {
    e.preventDefault();
    setIsPlateHovered(false);
    const slotIdStr = e.dataTransfer.getData('text/plain');
    const slotId = parseInt(slotIdStr, 10);
    if (!isNaN(slotId)) {
      // First move to cooked tray then plate, or plate directly!
      onPickUpCookedSkewer(slotId);
      setTimeout(() => {
        onPlateOneSkewer();
      }, 50);
    }
    setDraggedSlotId(null);
  };

  const handleLadleClick = () => {
    setSauceLadleAngle(18);
    setTimeout(() => setSauceLadleAngle(0), 350);
    if (currentOrder && (currentOrder.platedSkewers || 0) < currentOrder.skewers && cookedSquidTrayCount > 0) {
      onPlateOneSkewer();
    }
  };

  const handleServeWithConfetti = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch (e) {}
    onServeCurrentCustomer();
  };

  return (
    <div
      className="relative w-full h-[620px] md:h-[660px] overflow-hidden rounded-3xl select-none shadow-2xl border-4 border-amber-400/80"
      style={{
        background: 'linear-gradient(180deg, #1c142b 0%, #2b1f42 50%, #1f1530 100%)',
      }}
    >
      {/* 1. Charming Kawaii 2D Cartoon Anime Festival Street Background */}
      <div className="absolute inset-0 pointer-events-none">
        <img
          src="/src/assets/images/kawaii_cartoon_festival_1794301410242.jpg"
          alt="Cute Anime Food Festival"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-45 mix-blend-luminosity filter blur-[0.3px]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/75 to-slate-950/50" />

        {/* Cute Cartoon Hanging Festival Lanterns */}
        <div className="absolute top-2 left-6 flex items-center gap-4">
          <div className="flex flex-col items-center animate-bounce" style={{ animationDuration: '3.2s' }}>
            <div className="w-1.5 h-4 bg-amber-600 rounded-full" />
            <div className="w-11 h-14 bg-gradient-to-b from-red-500 via-rose-500 to-amber-400 rounded-3xl shadow-lg border-2 border-yellow-200 flex items-center justify-center">
              <span className="text-[11px] font-bold text-white font-['Mali'] drop-shadow">หมึกย่าง</span>
            </div>
          </div>
          <div className="flex flex-col items-center animate-bounce hidden sm:flex" style={{ animationDuration: '3.8s', animationDelay: '0.4s' }}>
            <div className="w-1.5 h-3 bg-amber-600 rounded-full" />
            <div className="w-10 h-13 bg-gradient-to-b from-amber-400 to-orange-500 rounded-3xl shadow-lg border-2 border-yellow-100 flex items-center justify-center">
              <span className="text-[10px] font-bold text-stone-900 font-['Mali']">งานวัด</span>
            </div>
          </div>
        </div>

        <div className="absolute top-2 right-6 flex items-center gap-4">
          <div className="flex flex-col items-center animate-bounce hidden sm:flex" style={{ animationDuration: '3.5s', animationDelay: '0.2s' }}>
            <div className="w-1.5 h-3 bg-amber-600 rounded-full" />
            <div className="w-10 h-13 bg-gradient-to-b from-amber-400 to-orange-500 rounded-3xl shadow-lg border-2 border-yellow-100 flex items-center justify-center">
              <span className="text-[10px] font-bold text-stone-900 font-['Mali']">รสเด็ด</span>
            </div>
          </div>
          <div className="flex flex-col items-center animate-bounce" style={{ animationDuration: '3s', animationDelay: '0.6s' }}>
            <div className="w-1.5 h-4 bg-amber-600 rounded-full" />
            <div className="w-11 h-14 bg-gradient-to-b from-red-500 via-rose-500 to-amber-400 rounded-3xl shadow-lg border-2 border-yellow-200 flex items-center justify-center">
              <span className="text-[11px] font-bold text-white font-['Mali'] drop-shadow">แซ่บเวอร์</span>
            </div>
          </div>
        </div>

        {/* Cute Cartoon Wooden Stall Title Header */}
        <div className="absolute top-2.5 left-1/2 -translate-x-1/2 z-10 text-center">
          <div className="px-6 py-1.5 bg-gradient-to-r from-amber-900 via-orange-950 to-amber-900 rounded-2xl border-3 border-amber-400 shadow-2xl flex items-center gap-3">
            <span className="text-2xl animate-spin" style={{ animationDuration: '10s' }}>🏮</span>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-wide text-yellow-300 font-['Mali'] drop-shadow">
                ร้านปลาหมึกย่างโบราณ เทศกาลงานวัด 🦑✨
              </h2>
              <div className="flex items-center justify-center gap-2 text-[11px] text-amber-200 font-['Itim']">
                <span>🔥 ย่างสุกแล้ว ใช้เมาส์ลากไปวางในถาดโชว์ได้เลย!</span>
              </div>
            </div>
            <span className="text-2xl animate-bounce" style={{ animationDuration: '2.5s' }}>🍢</span>
          </div>
        </div>
      </div>

      {/* 2. Helper Badge (Top Right) */}
      <div className="absolute right-4 top-18 z-20 flex items-center gap-2 pointer-events-none">
        {activeHelper ? (
          <div className="bg-slate-900/90 border-2 border-emerald-400 px-3 py-1.5 rounded-2xl shadow-xl flex items-center gap-2.5">
            <div className="relative">
              <div className="w-10 h-10 rounded-full p-0.5 bg-gradient-to-tr from-emerald-400 via-teal-300 to-yellow-300 shadow">
                {activeHelper.profilePictureUrl ? (
                  <img
                    src={activeHelper.profilePictureUrl}
                    alt={activeHelper.nickname}
                    className="w-full h-full rounded-full object-cover bg-slate-800"
                    referrerPolicy="no-referrer"
                    onError={(e) => ((e.target as HTMLElement).style.display = 'none')}
                  />
                ) : (
                  <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center text-sm font-bold text-white">
                    👨‍🍳
                  </div>
                )}
              </div>
              <span className="absolute -bottom-1 -right-1 text-[9px] bg-emerald-600 text-white font-bold px-1.5 rounded-full border border-white">
                เชฟ
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-emerald-300 font-['Prompt']">
                {activeHelper.nickname}
              </span>
              <span className="text-[10px] text-emerald-200 font-['Itim']">
                {activeHelper.giftName} (ช่วยย่าง {activeHelper.grilledCount} ไม้!)
              </span>
            </div>
          </div>
        ) : (
          <div className="bg-slate-900/80 border border-slate-700/80 px-3 py-1.5 rounded-2xl text-[11px] text-slate-300 font-['Itim'] flex items-center gap-1.5">
            <span>🪭</span>
            <span>รอคนดูส่งของขวัญมาช่วยย่าง...</span>
          </div>
        )}
      </div>

      {/* 3. Main Center Play Area */}
      <div className="absolute left-1/2 -translate-x-1/2 top-24 z-20 flex flex-col items-center w-full max-w-4xl px-3">
        {/* TOP TRAY: ถาดสำหรับวางปลาหมึกที่ย่างแล้ว (Drop Zone for Drag and Drop!) */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsTrayHovered(true);
          }}
          onDragLeave={() => setIsTrayHovered(false)}
          onDrop={handleDropOnTray}
          className={`w-full max-w-2xl rounded-2xl p-3 shadow-2xl transition-all duration-200 mb-3 border-3 flex flex-col sm:flex-row items-center justify-between gap-3 ${
            isTrayHovered
              ? 'bg-amber-900/90 border-yellow-300 shadow-yellow-500/40 scale-[1.02]'
              : 'bg-gradient-to-r from-amber-950 via-stone-900 to-amber-950 border-amber-400/80'
          }`}
        >
          <div className="flex items-center gap-3">
            {/* Cute Cartoon Display Tray Graphic */}
            <div className="relative w-16 h-12 bg-gradient-to-b from-stone-200 to-stone-400 rounded-xl border-2 border-stone-500 p-1 flex items-center justify-center shadow-inner">
              <div className="w-full h-full bg-emerald-700 rounded-lg flex items-center justify-center relative overflow-hidden">
                <span className="text-2xl drop-shadow">🍢</span>
                {cookedSquidTrayCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-yellow-400 text-stone-950 text-[9px] font-black px-1 rounded-full">
                    {cookedSquidTrayCount}
                  </span>
                )}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-yellow-300 font-['Mali']">
                  ถาดสำหรับวางปลาหมึกที่ย่างแล้ว (ลากมาวางตรงนี้!)
                </h3>
                <span className="px-2 py-0.5 bg-yellow-400 text-stone-950 text-[10px] font-black rounded-full font-mono">
                  {cookedSquidTrayCount} ไม้
                </span>
              </div>
              <p className="text-[11px] text-amber-200 font-['Itim']">
                {draggedSlotId
                  ? '✨ ปล่อยเมาส์ที่นี่เพื่อวางปลาหมึกลงในถาดโชว์!'
                  : '👉 ใช้เมาส์ลากปลาหมึกที่สุกแล้วจากเตามาวางโชว์ในถาดนี้ได้เลย!'}
              </p>
            </div>
          </div>

          {/* Quick fallback button: Pick up all cooked */}
          {anyCookedOnGrill && (
            <button
              onClick={onPickUpAllCooked}
              className="px-3.5 py-1.5 bg-gradient-to-r from-amber-400 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-stone-950 font-black rounded-xl text-xs font-['Prompt'] shadow transition shrink-0"
            >
              🥢 คีบทั้งหมดขึ้นถาด
            </button>
          )}
        </div>

        {/* MIDDLE TIER: [กล่องปลาหมึกสด] + [เตาย่าง 4 ช่อง พร้อมระบบลาก] + [โหลน้ำจิ้ม] */}
        <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-12 gap-3 items-stretch">
          {/* A. กล่องใส่ปลาหมึกสดเสียบไม้ (Raw Squid Prep Box) - 3 Cols */}
          <div className="md:col-span-3 bg-gradient-to-b from-sky-950 via-slate-900 to-sky-950 border-3 border-cyan-400/70 rounded-2xl p-3 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-black text-cyan-300 font-['Mali'] flex items-center gap-1">
                  <span>🧊</span> <span>กล่องปลาหมึกสดเสียบไม้</span>
                </span>
                <span className="text-xs font-mono font-black text-stone-950 bg-cyan-300 px-2 py-0.5 rounded-full">
                  {rawSquidStock} ไม้
                </span>
              </div>
              <p className="text-[10px] text-cyan-100 font-['Itim'] leading-tight">
                ปลาหมึกสดแช่น้ำแข็ง เมื่อเตาว่าง ไม้ใหม่จะขึ้นมาวางบนเตาต่ออัตโนมัติ!
              </p>
            </div>

            {/* Cute Cartoon Raw Squids in Iced Box */}
            <div className="my-2 p-2 bg-gradient-to-b from-cyan-900/50 to-slate-900 rounded-xl border border-cyan-400/40 flex items-center justify-around">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="flex flex-col items-center">
                  <div className="w-1 h-3 bg-amber-600 rounded-t" />
                  <div className="w-6 h-9 bg-gradient-to-b from-pink-100 to-pink-200 rounded-t-xl rounded-b-md border-2 border-pink-300 flex flex-col items-center justify-center p-0.5 shadow-sm">
                    {/* Cute Squid face */}
                    <div className="flex gap-1 -mt-1">
                      <div className="w-1 h-1 bg-stone-900 rounded-full" />
                      <div className="w-1 h-1 bg-stone-900 rounded-full" />
                    </div>
                    <div className="w-2 h-1 bg-pink-400/70 rounded-full my-0.5" />
                  </div>
                  <div className="w-1 h-3 bg-amber-600 rounded-b" />
                </div>
              ))}
            </div>

            <button
              onClick={onRefillRawSquids}
              className="w-full py-1.5 bg-cyan-500 hover:bg-cyan-400 text-stone-950 font-black rounded-xl text-xs font-['Prompt'] transition flex items-center justify-center gap-1 shadow"
            >
              <span>➕ เติมปลาหมึกสด (+10)</span>
            </button>
          </div>

          {/* B. เตาสำหรับย่างปลาหมึก (4-Slot Charcoal Grill with Drag-and-Drop) - 6 Cols */}
          <div className="md:col-span-6 bg-gradient-to-b from-stone-900 via-stone-950 to-black border-3 border-amber-600 rounded-2xl p-3 shadow-2xl flex flex-col justify-between relative overflow-hidden">
            {/* Header info */}
            <div className="relative z-10 flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <span className="text-base animate-pulse">🔥</span>
                <span className="text-xs font-black text-amber-300 font-['Mali']">
                  เตาย่างถ่านหิน (คลิกลากปลาหมึกที่สุกไปวางในถาด)
                </span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-['Prompt'] ${
                isGrillingFast ? 'bg-orange-500 text-stone-950 font-black' : 'bg-stone-800 text-amber-300'
              }`}>
                {isGrillingFast ? '🔥 ไฟแรงพิเศษ!' : 'ไฟเตาปกติ'}
              </span>
            </div>

            {/* 4 Interactive Grill Slots with Real Squid Skewers and Drag-and-Drop */}
            <div className="relative z-10 grid grid-cols-4 gap-2 h-44 items-stretch">
              {grillSlots.map((slot) => {
                const isCooked = slot.status === 'cooked';
                const isRaw = slot.status === 'raw';
                const percent = Math.min(100, Math.round(slot.doneness));
                const isBeingDragged = draggedSlotId === slot.id;

                return (
                  <div
                    key={slot.id}
                    draggable={isCooked}
                    onDragStart={(e) => handleDragStart(e, slot)}
                    onDragEnd={handleDragEnd}
                    onClick={() => {
                      if (isCooked) {
                        onPickUpCookedSkewer(slot.id);
                      }
                    }}
                    className={`relative rounded-2xl border-2 p-1.5 flex flex-col items-center justify-between transition-all duration-200 select-none ${
                      isCooked
                        ? 'border-yellow-400 bg-amber-500/25 shadow-lg shadow-orange-500/40 cursor-grab active:cursor-grabbing hover:scale-105'
                        : 'border-stone-700 bg-stone-900/70'
                    } ${isBeingDragged ? 'opacity-40 scale-95' : ''}`}
                    title={
                      isCooked
                        ? '✨ สุกแล้ว! คลิกคีบ หรือคลิกลากไปวางในถาด'
                        : 'กำลังย่างปลาหมึก...'
                    }
                  >
                    {/* Doneness Badge Status */}
                    <div className="w-full text-center">
                      {isCooked ? (
                        <div className="bg-gradient-to-r from-yellow-400 to-amber-400 text-stone-950 text-[9px] font-black px-1 py-0.5 rounded-md shadow-md font-['Mali'] animate-pulse">
                          ✨ สุกแล้ว! ลากได้
                        </div>
                      ) : (
                        <div className="text-[9px] font-bold text-amber-200 font-mono">
                          {isRaw ? 'เพิ่งลงเตา' : `${percent}%`}
                        </div>
                      )}
                    </div>

                    {/* Doneness Progress Bar */}
                    <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden my-1 border border-stone-700">
                      <div
                        className={`h-full transition-all duration-300 ${
                          isCooked
                            ? 'bg-yellow-400'
                            : percent > 60
                            ? 'bg-orange-500'
                            : 'bg-emerald-400'
                        }`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>

                    {/* Cute Cartoon Squid Skewer Graphic */}
                    <div className="relative flex flex-col items-center">
                      <div className="w-1.5 h-3 bg-amber-600 rounded-t" />

                      {/* Cartoon Squid Body */}
                      <div
                        className={`w-9 h-14 rounded-t-2xl rounded-b-lg shadow-md border-2 flex flex-col items-center justify-between p-1 transition-colors duration-300 ${
                          isCooked
                            ? 'bg-gradient-to-b from-amber-400 via-orange-400 to-amber-600 border-yellow-200 shadow-orange-500/80'
                            : percent > 40
                            ? 'bg-gradient-to-b from-amber-200 via-orange-200 to-amber-300 border-amber-300'
                            : 'bg-gradient-to-b from-pink-100 to-pink-200 border-pink-200'
                        }`}
                      >
                        {/* Side Wings */}
                        <div className="w-full flex justify-between px-0.5 -mt-0.5">
                          <div className={`w-2 h-2.5 rounded-tl-lg ${isCooked ? 'bg-amber-300' : 'bg-pink-300'}`} />
                          <div className={`w-2 h-2.5 rounded-tr-lg ${isCooked ? 'bg-amber-300' : 'bg-pink-300'}`} />
                        </div>

                        {/* Cute eyes & smile */}
                        <div className="flex flex-col items-center -mt-1">
                          <div className="flex gap-2">
                            <div className="w-1 h-1 bg-stone-950 rounded-full" />
                            <div className="w-1 h-1 bg-stone-950 rounded-full" />
                          </div>
                          <div className="w-2 h-0.5 bg-stone-900 rounded-full mt-0.5" />
                        </div>

                        {/* Cute Grill Marks */}
                        <div className="w-full flex flex-col gap-1 items-center">
                          <div className={`w-6 h-0.5 rounded ${isCooked ? 'bg-amber-950' : 'bg-amber-800/20'}`} />
                          <div className={`w-7 h-0.5 rounded ${isCooked ? 'bg-amber-950' : 'bg-amber-800/20'}`} />
                        </div>

                        {/* Tentacles */}
                        <div className="flex gap-0.5 -mb-1">
                          <div className={`w-1.5 h-2 rounded-b ${isCooked ? 'bg-orange-600' : 'bg-pink-300'}`} />
                          <div className={`w-1.5 h-3 rounded-b ${isCooked ? 'bg-amber-600' : 'bg-pink-400'}`} />
                          <div className={`w-1.5 h-2 rounded-b ${isCooked ? 'bg-orange-600' : 'bg-pink-300'}`} />
                        </div>

                        {isCooked && (
                          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <span className="text-xs drop-shadow">🌶️</span>
                          </div>
                        )}
                      </div>

                      <div className="w-2 h-4 bg-amber-600 rounded-b shadow" />
                    </div>

                    <span className="text-[9px] text-amber-200 font-['Itim']">
                      {isCooked ? 'ลาก / แตะ' : 'กำลังย่าง'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* C. โหลน้ำจิ้มซีฟู้ดที่ดูน่ากิน (Appetizing Seafood Sauce Jar) - 3 Cols */}
          <div
            onClick={handleLadleClick}
            className="md:col-span-3 bg-gradient-to-b from-emerald-950 via-slate-900 to-emerald-950 border-3 border-emerald-400/70 rounded-2xl p-3 shadow-xl flex flex-col justify-between cursor-pointer hover:border-emerald-300 transition"
            title="คลิกที่โหลน้ำจิ้มเพื่อตักราดปลาหมึกใส่จานลูกค้า!"
          >
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-black text-emerald-300 font-['Mali'] flex items-center gap-1">
                  <span>🌶️</span> <span>โหลน้ำจิ้มซีฟู้ดรสแซ่บ</span>
                </span>
                <span className="text-[10px] font-bold text-stone-900 bg-emerald-300 px-1.5 py-0.5 rounded font-['Prompt']">
                  มะนาวแท้
                </span>
              </div>
              <p className="text-[10px] text-emerald-100 font-['Itim'] leading-tight">
                พริกขี้หนูสด มะนาวแท้ กระเทียมไทย หอมแซ่บ แตะเพื่อตักน้ำจิ้มราดใส่จาน!
              </p>
            </div>

            {/* Realistic Detailed Glass Sauce Jar Graphic */}
            <div className="relative my-2 w-full h-24 bg-gradient-to-b from-white/30 via-emerald-700/80 to-emerald-900/90 rounded-b-2xl rounded-t-md border-2 border-emerald-300 shadow-xl overflow-hidden flex flex-col justify-between p-1">
              <div className="w-full h-2 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 rounded-t shadow" />

              <div className="relative flex-1 bg-gradient-to-b from-emerald-500/90 to-emerald-700/95 rounded-b-xl overflow-hidden flex items-center justify-around">
                <span className="text-base drop-shadow animate-pulse">🍋</span>
                <span className="text-base drop-shadow animate-bounce" style={{ animationDuration: '2s' }}>🌶️</span>
                <span className="text-sm drop-shadow">🧄</span>

                {/* Bamboo Ladle Dipping in */}
                <div
                  className="absolute -top-3 right-4 w-2 h-16 bg-gradient-to-b from-amber-200 to-amber-600 rounded shadow-md transition-transform duration-300"
                  style={{ transform: `rotate(${sauceLadleAngle - 15}deg)` }}
                />
              </div>
            </div>

            <div className="text-center bg-emerald-500 text-stone-950 font-black py-1 rounded-xl text-[10px] font-['Prompt'] shadow">
              👉 แตะเพื่อตักน้ำจิ้มราดใส่จาน
            </div>
          </div>
        </div>

        {/* 4. BOTTOM TIER: แผงคนขายเอาปลาหมึกใส่จานส่งให้ลูกค้า (Drop Zone also supported!) */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsPlateHovered(true);
          }}
          onDragLeave={() => setIsPlateHovered(false)}
          onDrop={handleDropOnPlate}
          className={`w-full max-w-3xl mt-3 rounded-2xl p-3 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-3 border-3 transition-colors ${
            isPlateHovered
              ? 'bg-amber-900/90 border-yellow-300 shadow-yellow-500/40'
              : 'bg-gradient-to-r from-stone-900 via-amber-950 to-stone-900 border-amber-400/80'
          }`}
        >
          {/* Customer Info at Front Counter */}
          <div className="flex items-center gap-3">
            {currentOrder ? (
              <div className="flex items-center gap-3">
                <div className="relative shrink-0">
                  <div className="w-13 h-13 rounded-full p-0.5 bg-gradient-to-tr from-yellow-300 via-pink-400 to-purple-500 shadow-lg">
                    {currentOrder.profilePictureUrl ? (
                      <img
                        src={currentOrder.profilePictureUrl}
                        alt={currentOrder.nickname}
                        className="w-full h-full rounded-full object-cover bg-slate-800"
                        referrerPolicy="no-referrer"
                        onError={(e) => ((e.target as HTMLElement).style.display = 'none')}
                      />
                    ) : (
                      <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center font-bold text-white text-sm">
                        {currentOrder.nickname.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                  </div>
                  <span className="absolute -bottom-1 -right-1 text-xs">👑</span>
                </div>

                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white font-['Prompt']">
                      ลูกค้า: {currentOrder.nickname}
                    </span>
                    <span className="text-[10px] bg-red-500 text-white px-2 py-0.5 rounded-full font-black">
                      สั่ง {currentOrder.skewers} ไม้
                    </span>
                  </div>
                  <span className="text-[11px] text-yellow-300 font-['Itim']">
                    {currentOrder.giftName} (ของขวัญจาก TikTok)
                  </span>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-xs text-amber-200/80 font-['Itim'] py-1">
                <span className="text-lg">⏳</span>
                <span>ยังไม่มีออเดอร์ค้าง ลากปลาหมึกสุกมาวางตุนไว้ในถาดได้เลย!</span>
              </div>
            )}
          </div>

          {/* The Customer Serving Plate */}
          <div className="flex items-center gap-3 bg-slate-950/80 px-3 py-2 rounded-xl border border-amber-400/60 shadow">
            <div className="relative w-14 h-11 bg-slate-100 rounded-full border border-slate-300 shadow flex items-center justify-center p-0.5">
              <div className="w-12 h-9 bg-emerald-600 rounded-full border border-emerald-400 flex items-center justify-center relative overflow-hidden">
                <span className="text-base drop-shadow">🍢</span>
                <span className="absolute bottom-0 right-1 text-[9px]">🍋</span>
              </div>
            </div>

            <div className="flex flex-col">
              <span className="text-xs font-black text-amber-300 font-['Mali']">
                จานสำหรับส่งให้ลูกค้า
              </span>
              <span className="text-xs font-mono font-bold text-white">
                {currentOrder ? (
                  <span>
                    ใส่จานแล้ว: <strong className="text-yellow-400 font-black">{currentOrder.platedSkewers || 0}</strong> / {currentOrder.skewers} ไม้
                  </span>
                ) : (
                  <span className="text-slate-400 font-normal">จานสะอาดพร้อมเสิร์ฟ</span>
                )}
              </span>
            </div>
          </div>

          {/* Plating Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {currentOrder && !isPlateReadyToServe && (
              <>
                <button
                  onClick={onPlateOneSkewer}
                  disabled={cookedSquidTrayCount <= 0}
                  className="px-3 py-2 bg-amber-400 hover:bg-amber-300 disabled:opacity-40 text-stone-950 font-black rounded-xl text-xs font-['Prompt'] transition flex items-center gap-1 shadow"
                >
                  <span>🥢 คีบใส่จาน (+1)</span>
                </button>

                <button
                  onClick={onPlateAllForCurrentOrder}
                  disabled={cookedSquidTrayCount <= 0}
                  className="px-3 py-2 bg-gradient-to-r from-amber-400 to-orange-400 hover:from-amber-300 hover:to-orange-300 disabled:opacity-40 text-stone-950 font-black rounded-xl text-xs font-['Prompt'] transition flex items-center gap-1 shadow"
                >
                  <span>🥢 คีบให้ครบ ({neededForCurrent})</span>
                </button>
              </>
            )}

            {currentOrder && isPlateReadyToServe && (
              <button
                onClick={handleServeWithConfetti}
                className="px-5 py-2.5 bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-400 hover:from-emerald-300 hover:to-teal-200 text-stone-950 font-black rounded-xl text-xs font-['Prompt'] transition flex items-center gap-1.5 shadow-xl shadow-emerald-500/40 animate-pulse"
              >
                <span>🚀</span>
                <span>ส่งจานให้ลูกค้าทันที!</span>
              </button>
            )}

            {!currentOrder && (
              <div className="text-[11px] text-amber-200 font-['Prompt'] px-2">
                เสิร์ฟแล้วทั้งหมด: <strong className="text-yellow-400 font-black">{totalServed}</strong> ไม้
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
