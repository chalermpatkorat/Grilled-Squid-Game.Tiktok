import React from 'react';
import { LiveEventNotification } from '../types/game';

interface OrderNotificationAlertProps {
  notifications: LiveEventNotification[];
}

export const OrderNotificationAlert: React.FC<OrderNotificationAlertProps> = ({ notifications }) => {
  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-40 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {notifications.map((notif) => (
        <div
          key={notif.id}
          className={`flex items-center gap-3 p-3.5 rounded-2xl border shadow-2xl backdrop-blur-md transform transition-all duration-300 animate-slide-in ${
            notif.type === 'order'
              ? 'bg-slate-900/95 border-amber-500/60 shadow-amber-500/20 text-white'
              : notif.type === 'helper'
              ? 'bg-slate-900/95 border-emerald-500/60 shadow-emerald-500/20 text-white'
              : 'bg-slate-900/95 border-pink-500/60 shadow-pink-500/20 text-white'
          }`}
        >
          {/* Avatar / Icon */}
          <div className="relative shrink-0">
            <div
              className={`w-12 h-12 rounded-full p-0.5 ${
                notif.type === 'order'
                  ? 'bg-gradient-to-tr from-amber-400 to-orange-500'
                  : notif.type === 'helper'
                  ? 'bg-gradient-to-tr from-emerald-400 to-teal-500'
                  : 'bg-gradient-to-tr from-pink-400 to-rose-500'
              }`}
            >
              {notif.avatar ? (
                <img
                  src={notif.avatar}
                  alt={notif.title}
                  className="w-full h-full rounded-full object-cover bg-slate-800"
                  referrerPolicy="no-referrer"
                  onError={(e) => ((e.target as HTMLElement).style.display = 'none')}
                />
              ) : (
                <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center text-lg">
                  {notif.badge || '🎁'}
                </div>
              )}
            </div>
            {notif.badge && (
              <span className="absolute -bottom-1 -right-1 text-sm bg-black/60 rounded-full px-1">
                {notif.badge}
              </span>
            )}
          </div>

          {/* Details */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-1">
              <span className="text-xs font-bold text-amber-300 truncate font-['Prompt']">
                {notif.title}
              </span>
              <span className="text-[10px] text-slate-400 font-mono">เมื่อสักครู่</span>
            </div>
            <p className="text-sm font-semibold text-white leading-tight mt-0.5 font-['Prompt']">
              {notif.description}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};
