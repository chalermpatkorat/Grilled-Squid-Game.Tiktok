import React, { useState } from 'react';
import { TikTokStatus } from '../types/game';

interface TikTokConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: TikTokStatus;
  onConnect: (username: string) => Promise<void>;
  onDisconnect: () => Promise<void>;
  onSimulate: (data: {
    giftType?: string;
    nickname?: string;
    uniqueId?: string;
    profilePictureUrl?: string;
    count?: number;
    isLike?: boolean;
  }) => Promise<void>;
  isAutoSimulating: boolean;
  onToggleAutoSimulate: () => void;
}

export const TikTokConnectModal: React.FC<TikTokConnectModalProps> = ({
  isOpen,
  onClose,
  status,
  onConnect,
  onDisconnect,
  onSimulate,
  isAutoSimulating,
  onToggleAutoSimulate,
}) => {
  const [inputUsername, setInputUsername] = useState(status.username || '');
  const [customName, setCustomName] = useState('สายเปย์ตัวแม่');
  const [customAvatar, setCustomAvatar] = useState(
    'https://api.dicebear.com/7.x/bottts/svg?seed=LuckyChef'
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState('');

  if (!isOpen) return null;

  const handleConnectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUsername.trim()) return;
    setIsSubmitting(true);
    setFeedbackMsg('');
    try {
      await onConnect(inputUsername);
    } catch (err: any) {
      setFeedbackMsg(err?.message || 'เชื่อมต่อไม่สำเร็จ');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickGift = async (giftType: string, count: number = 1) => {
    setFeedbackMsg(`ส่งของขวัญ "${giftType}" เรียบร้อย!`);
    await onSimulate({
      giftType,
      count,
      nickname: customName || 'ผู้ชมในไลฟ์',
      uniqueId: (customName || 'viewer').toLowerCase().replace(/\s+/g, '_'),
      profilePictureUrl: customAvatar,
    });
    setTimeout(() => setFeedbackMsg(''), 2500);
  };

  const handleQuickLikes = async (likesCount: number = 100) => {
    setFeedbackMsg(`เคาะจอเคาะใจ ${likesCount} ครั้งเรียบร้อย!`);
    await onSimulate({
      isLike: true,
      count: likesCount,
      nickname: customName || 'ผู้ชมสายเคาะ',
      uniqueId: (customName || 'tapper').toLowerCase().replace(/\s+/g, '_'),
      profilePictureUrl: customAvatar,
    });
    setTimeout(() => setFeedbackMsg(''), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white text-xl p-1 rounded-lg hover:bg-slate-800"
        >
          ✕
        </button>

        {/* Modal Title */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-500 via-rose-500 to-amber-500 flex items-center justify-center text-xl shadow">
            📡
          </div>
          <div>
            <h2 className="text-xl font-bold text-white font-['Prompt']">
              เชื่อมต่อ TikTok Live & แผงควบคุมของขวัญ
            </h2>
            <p className="text-xs text-slate-400 font-['Prompt']">
              เชื่อมต่อไลฟ์สดแบบเรียลไทม์ หรือทดสอบจำลองการส่งของขวัญและเคาะจอ
            </p>
          </div>
        </div>

        {/* Status Alert Banner */}
        <div
          className={`p-3.5 rounded-xl border mb-5 text-xs flex items-center justify-between gap-3 font-['Prompt'] ${
            status.status === 'connected'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : status.status === 'connecting'
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              : status.status === 'error'
              ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
              : 'bg-slate-800/60 border-slate-700 text-slate-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                status.status === 'connected'
                  ? 'bg-emerald-400 animate-pulse'
                  : status.status === 'connecting'
                  ? 'bg-amber-400 animate-ping'
                  : status.status === 'error'
                  ? 'bg-rose-400'
                  : 'bg-slate-500'
              }`}
            />
            <span>
              สถานะ:{' '}
              <strong className="uppercase">
                {status.status === 'connected'
                  ? `กำลังเชื่อมต่อกับ @${status.username}`
                  : status.status === 'connecting'
                  ? `กำลังค้นหาห้องไลฟ์ @${status.username}...`
                  : status.status === 'error'
                  ? 'เกิดข้อผิดพลาดในการเชื่อมต่อ'
                  : 'ยังไม่ได้เชื่อมต่อกับ TikTok Live'}
              </strong>
            </span>
          </div>

          {status.status === 'connected' && (
            <button
              onClick={onDisconnect}
              className="px-3 py-1 bg-rose-600/80 hover:bg-rose-600 text-white font-medium rounded-lg text-xs transition"
            >
              ตัดการเชื่อมต่อ
            </button>
          )}
        </div>

        {/* Connect Form */}
        <form onSubmit={handleConnectSubmit} className="mb-6">
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 font-['Prompt']">
            ชื่อผู้ใช้ TikTok (TikTok Username หรือ Handle)
          </label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono">
                @
              </span>
              <input
                type="text"
                value={inputUsername}
                onChange={(e) => setInputUsername(e.target.value)}
                placeholder="เช่น somchai_squid_live หรือ username ของคุณ"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-8 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-pink-500 transition font-mono"
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting || status.status === 'connecting'}
              className="px-5 py-2.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 disabled:opacity-50 text-white font-semibold rounded-xl text-sm transition shadow font-['Prompt'] shrink-0"
            >
              {isSubmitting ? 'กำลังเชื่อมต่อ...' : 'เชื่อมต่อ Live'}
            </button>
          </div>
          <p className="text-[11px] text-slate-400 mt-1.5 font-['Prompt']">
            💡 <strong>คำแนะนำ:</strong> บัญชี TikTok จะต้องกำลัง "เปิดไลฟ์สดอยู่จริง" ณ ขณะนั้น
            หากยังไม่ได้เปิดไลฟ์ หรือต้องการซ้อมก่อนไลฟ์ สามารถใช้{' '}
            <span className="text-amber-300 font-medium">แผงจำลองด้านล่าง</span> ได้เลยทันที!
          </p>
        </form>

        {feedbackMsg && (
          <div className="mb-4 p-2.5 bg-amber-500/20 border border-amber-500/40 text-amber-200 rounded-xl text-xs text-center font-['Prompt']">
            {feedbackMsg}
          </div>
        )}

        {/* Gift Mappings & Simulator Box */}
        <div className="bg-slate-800/60 border border-slate-700 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-base">🎮</span>
              <h4 className="text-sm font-bold text-white font-['Prompt']">
                แผงทดสอบของขวัญ & ซิมูเลเตอร์ Live (คลิกเพื่อทดสอบทันที)
              </h4>
            </div>

            {/* Auto-Simulate Toggle */}
            <button
              onClick={onToggleAutoSimulate}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold font-['Prompt'] transition flex items-center gap-1.5 ${
                isAutoSimulating
                  ? 'bg-emerald-500 text-stone-950 shadow-md'
                  : 'bg-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <span>{isAutoSimulating ? '🟢 กำลังจำลองคนดูอัตโนมัติ' : '⚪ เปิดบอทจำลองคนดู'}</span>
            </button>
          </div>

          {/* Custom Viewer Preview Input */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-4 bg-slate-900/60 p-2.5 rounded-xl border border-slate-700/60">
            <div>
              <label className="text-[11px] text-slate-400 font-['Prompt']">ชื่อคนส่งของขวัญ:</label>
              <input
                type="text"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white mt-0.5 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 font-['Prompt']">รูปโปรไฟล์ (URL):</label>
              <input
                type="text"
                value={customAvatar}
                onChange={(e) => setCustomAvatar(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white mt-0.5 focus:outline-none"
              />
            </div>
          </div>

          {/* Gift Buttons: Section 1 - Order Gifts */}
          <div className="mb-3">
            <span className="text-[11px] font-bold text-amber-400 font-['Prompt'] block mb-2">
              🛒 ของขวัญสั่งปลาหมึกย่าง:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <button
                onClick={() => handleQuickGift('rose', 1)}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center gap-2"
              >
                <span className="text-xl">🌹</span>
                <div>
                  <div className="text-xs font-bold text-white font-['Prompt']">ดอกกุหลาบ</div>
                  <div className="text-[10px] text-amber-300 font-['Prompt']">= สั่ง 1 ไม้</div>
                </div>
              </button>

              <button
                onClick={() => handleQuickGift('finger heart', 1)}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center gap-2"
              >
                <span className="text-xl">🫰</span>
                <div>
                  <div className="text-xs font-bold text-white font-['Prompt']">หัวใจนิ้ว</div>
                  <div className="text-[10px] text-amber-300 font-['Prompt']">= สั่ง 5 ไม้</div>
                </div>
              </button>

              <button
                onClick={() => handleQuickGift('perfume', 1)}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center gap-2"
              >
                <span className="text-xl">🧴</span>
                <div>
                  <div className="text-xs font-bold text-white font-['Prompt']">น้ำหอม</div>
                  <div className="text-[10px] text-amber-300 font-['Prompt']">= สั่ง 10 ไม้</div>
                </div>
              </button>

              <button
                onClick={() => handleQuickGift('doughnut', 1)}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center gap-2"
              >
                <span className="text-xl">🍩</span>
                <div>
                  <div className="text-xs font-bold text-white font-['Prompt']">โดนัท</div>
                  <div className="text-[10px] text-amber-300 font-['Prompt']">= สั่ง 20 ไม้</div>
                </div>
              </button>

              <button
                onClick={() => handleQuickGift('cap and mustache', 1)}
                className="p-2 bg-gradient-to-r from-amber-900/60 to-purple-900/60 hover:from-amber-900/80 hover:to-purple-900/80 border border-yellow-500/40 rounded-xl text-left transition flex items-center gap-2 col-span-2 sm:col-span-2"
              >
                <span className="text-xl">🎩🥸</span>
                <div>
                  <div className="text-xs font-bold text-yellow-300 font-['Prompt'] flex items-center gap-1">
                    <span>หมวกกับหนวด</span>
                    <span className="text-[9px] bg-yellow-400 text-stone-900 px-1 rounded font-bold">แจ็คพอต!</span>
                  </div>
                  <div className="text-[10px] text-yellow-200 font-['Prompt']">
                    = สุ่มสั่ง 20 - 100 ไม้ (ลุ้นระทึก)
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Gift Buttons: Section 2 - Helper Gifts */}
          <div>
            <span className="text-[11px] font-bold text-emerald-400 font-['Prompt'] block mb-2">
              👨‍🍳 ของขวัญช่วยย่างปลาหมึก:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={() => handleQuickGift('very good', 1)}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center gap-2"
              >
                <span className="text-xl">👍</span>
                <div>
                  <div className="text-xs font-bold text-white font-['Prompt']">เยี่ยมสุดๆ</div>
                  <div className="text-[10px] text-emerald-300 font-['Prompt']">= ช่วยย่าง 2 ไม้</div>
                </div>
              </button>

              <button
                onClick={() => handleQuickGift('mini dino', 1)}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center gap-2"
              >
                <span className="text-xl">🦖</span>
                <div>
                  <div className="text-xs font-bold text-white font-['Prompt']">ไดโนเสาร์จิ๋ว</div>
                  <div className="text-[10px] text-emerald-300 font-['Prompt']">= ช่วยย่าง 20 ไม้</div>
                </div>
              </button>

              <button
                onClick={() => handleQuickGift('mishka bear', 1)}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center gap-2"
              >
                <span className="text-xl">🐻</span>
                <div>
                  <div className="text-xs font-bold text-white font-['Prompt']">หมีมีชคา</div>
                  <div className="text-[10px] text-emerald-300 font-['Prompt']">= ช่วยย่าง 100 ไม้</div>
                </div>
              </button>

              <button
                onClick={() => handleQuickLikes(100)}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-pink-500/30 rounded-xl text-left transition flex items-center gap-2"
              >
                <span className="text-xl">❤️</span>
                <div>
                  <div className="text-xs font-bold text-pink-300 font-['Prompt']">เคาะจอ 100 ใจ</div>
                  <div className="text-[10px] text-emerald-300 font-['Prompt']">= ช่วยย่าง 1 ไม้</div>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="mt-5 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-medium rounded-xl text-xs font-['Prompt'] transition"
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
};
