import React from 'react';
import { TikTokStatus } from '../types/game';

interface StreamerControlDockProps {
  status: TikTokStatus;
  onOpenConnectModal: () => void;
  onOpenSummaryModal: () => void;
  onSimulateGift: (giftType: string, count?: number) => void;
  onSimulateLike: (count?: number) => void;
  isBgmOn: boolean;
  onToggleBgm: () => void;
  isTtsOn: boolean;
  onToggleTts: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const StreamerControlDock: React.FC<StreamerControlDockProps> = ({
  status,
  onOpenConnectModal,
  onOpenSummaryModal,
  onSimulateGift,
  onSimulateLike,
  isBgmOn,
  onToggleBgm,
  isTtsOn,
  onToggleTts,
  isMuted,
  onToggleMute,
}) => {
  return (
    <div className="w-full bg-slate-900/95 border-t border-slate-800 p-3 flex flex-col gap-2.5 shadow-2xl backdrop-blur-md">
      {/* Top row of control bar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        {/* TikTok Live Status indicator */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenConnectModal}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold font-['Prompt'] flex items-center gap-2 transition shadow-sm ${
              status.status === 'connected'
                ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 hover:bg-emerald-500/30'
                : status.status === 'connecting'
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 hover:bg-amber-500/30'
                : 'bg-pink-600/20 border-pink-500/50 text-pink-300 hover:bg-pink-600/30'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                status.status === 'connected'
                  ? 'bg-emerald-400 animate-pulse'
                  : status.status === 'connecting'
                  ? 'bg-amber-400 animate-ping'
                  : 'bg-pink-400'
              }`}
            />
            <span>
              {status.status === 'connected'
                ? `TikTok: @${status.username} (เชื่อมต่อแล้ว)`
                : status.status === 'connecting'
                ? `กำลังเชื่อมต่อ @${status.username}...`
                : '🔗 เชื่อมต่อ TikTok Live'}
            </span>
          </button>

          {/* Quick Sound & TTS Controls */}
          <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700">
            <button
              onClick={onToggleBgm}
              className={`px-2 py-1 rounded-lg text-xs transition font-['Prompt'] ${
                isBgmOn ? 'bg-amber-500 text-stone-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="เปิด/ปิด เสียงเพลงประกอบเบาๆ"
            >
              🎵 เพลง {isBgmOn ? 'เปิด' : 'ปิด'}
            </button>

            <button
              onClick={onToggleTts}
              className={`px-2 py-1 rounded-lg text-xs transition font-['Prompt'] ${
                isTtsOn ? 'bg-indigo-500 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="เปิด/ปิด เสียงพูดพากย์ออเดอร์ภาษาไทย"
            >
              🗣️ เสียงพูด {isTtsOn ? 'เปิด' : 'ปิด'}
            </button>

            <button
              onClick={onToggleMute}
              className={`px-2 py-1 rounded-lg text-xs transition font-['Prompt'] ${
                isMuted ? 'bg-rose-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="ปิดเสียงเอฟเฟกต์ทั้งหมด"
            >
              {isMuted ? '🔇 ปิดเสียง' : '🔊 เปิดเสียง'}
            </button>
          </div>
        </div>

        {/* End Live & Summary Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSummaryModal}
            className="px-4 py-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-400 hover:to-red-400 text-stone-950 font-black rounded-xl text-xs font-['Prompt'] shadow-lg transition flex items-center gap-1.5"
          >
            <span>🏁</span>
            <span>สรุปยอดปิดไลฟ์สด</span>
          </button>
        </div>
      </div>

      {/* Quick Test Gift Trigger Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <span className="text-[11px] font-bold text-slate-400 shrink-0 font-['Prompt']">
          ทดสอบกดส่งของขวัญ:
        </span>

        {/* Order gifts */}
        <button
          onClick={() => onSimulateGift('rose', 1)}
          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg shrink-0 border border-slate-700 font-['Prompt'] flex items-center gap-1 transition"
        >
          <span>🌹</span> <span>กุหลาบ (1 ไม้)</span>
        </button>

        <button
          onClick={() => onSimulateGift('finger heart', 1)}
          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg shrink-0 border border-slate-700 font-['Prompt'] flex items-center gap-1 transition"
        >
          <span>🫰</span> <span>หัวใจนิ้ว (5 ไม้)</span>
        </button>

        <button
          onClick={() => onSimulateGift('perfume', 1)}
          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg shrink-0 border border-slate-700 font-['Prompt'] flex items-center gap-1 transition"
        >
          <span>🧴</span> <span>น้ำหอม (10 ไม้)</span>
        </button>

        <button
          onClick={() => onSimulateGift('doughnut', 1)}
          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg shrink-0 border border-slate-700 font-['Prompt'] flex items-center gap-1 transition"
        >
          <span>🍩</span> <span>โดนัท (20 ไม้)</span>
        </button>

        <button
          onClick={() => onSimulateGift('cap and mustache', 1)}
          className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-yellow-300 rounded-lg shrink-0 border border-yellow-500/40 font-['Prompt'] flex items-center gap-1 font-bold transition"
        >
          <span>🎩🥸</span> <span>หมวกหนวด (สุ่ม 20-100)</span>
        </button>

        {/* Helper gifts */}
        <button
          onClick={() => onSimulateGift('very good', 1)}
          className="px-2.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 rounded-lg shrink-0 border border-emerald-500/40 font-['Prompt'] flex items-center gap-1 transition"
        >
          <span>👍</span> <span>เยี่ยมสุดๆ (ช่วย 2)</span>
        </button>

        <button
          onClick={() => onSimulateGift('mini dino', 1)}
          className="px-2.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 rounded-lg shrink-0 border border-emerald-500/40 font-['Prompt'] flex items-center gap-1 transition"
        >
          <span>🦖</span> <span>ไดโนเสาร์ (ช่วย 20)</span>
        </button>

        <button
          onClick={() => onSimulateGift('mishka bear', 1)}
          className="px-2.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 rounded-lg shrink-0 border border-emerald-500/40 font-['Prompt'] flex items-center gap-1 font-bold transition"
        >
          <span>🐻</span> <span>หมีมีชคา (ช่วย 100)</span>
        </button>

        <button
          onClick={() => onSimulateLike(100)}
          className="px-2.5 py-1 bg-pink-500/20 hover:bg-pink-500/30 text-pink-300 rounded-lg shrink-0 border border-pink-500/40 font-['Prompt'] flex items-center gap-1 transition"
        >
          <span>❤️</span> <span>เคาะ 100 ใจ (ช่วย 1)</span>
        </button>
      </div>
    </div>
  );
};
