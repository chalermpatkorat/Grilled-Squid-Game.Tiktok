import React from 'react';
import { LeaderboardEntry } from '../types/game';

interface TopHUDLeaderboardProps {
  topBuyers: LeaderboardEntry[];
  topHelpers: LeaderboardEntry[];
  totalOrdered: number;
  totalGrilled: number;
  readyWarmSkewers: number;
  totalRevenueEstimate: number;
}

export const TopHUDLeaderboard: React.FC<TopHUDLeaderboardProps> = ({
  topBuyers,
  topHelpers,
  totalOrdered,
  totalGrilled,
  readyWarmSkewers,
  totalRevenueEstimate,
}) => {
  // Grab top 3 only
  const buyersTop3 = [0, 1, 2].map((idx) => topBuyers[idx] || null);
  const helpersTop3 = [0, 1, 2].map((idx) => topHelpers[idx] || null);

  const medals = ['🥇', '🥈', '🥉'];
  const buyerMedalColors = [
    'from-yellow-400 to-amber-500 border-yellow-300 text-yellow-300',
    'from-slate-300 to-slate-400 border-slate-300 text-slate-200',
    'from-amber-600 to-amber-700 border-amber-600 text-amber-300',
  ];
  const helperMedalColors = [
    'from-emerald-400 to-teal-500 border-emerald-300 text-emerald-300',
    'from-teal-300 to-cyan-400 border-teal-300 text-teal-200',
    'from-emerald-600 to-teal-700 border-emerald-600 text-emerald-300',
  ];

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-3 sm:p-3.5 shadow-xl backdrop-blur-md">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">
        {/* Left Side: Top 3 Buyers (5 Cols on LG) */}
        <div className="lg:col-span-5 flex flex-col gap-1.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 font-['Prompt']">
              <span>🏆</span>
              <span>ยอดผู้ซื้อสูงสุด (Top 3)</span>
            </div>
            <span className="text-[11px] text-slate-400 font-['Prompt']">สั่งสะสม</span>
          </div>

          <div className="grid grid-cols-3 gap-1.5">
            {buyersTop3.map((buyer, idx) => {
              const medal = medals[idx];
              const colorCls = buyerMedalColors[idx];

              return (
                <div
                  key={idx}
                  className={`p-1.5 rounded-xl border bg-slate-950/60 flex items-center gap-2 min-w-0 transition-colors ${
                    buyer
                      ? 'border-amber-500/30 hover:border-amber-500/50'
                      : 'border-slate-800/80 opacity-60'
                  }`}
                >
                  {/* Medal & Avatar */}
                  <div className="relative shrink-0">
                    <div className="w-8 h-8 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 to-orange-500">
                      {buyer?.profilePictureUrl ? (
                        <img
                          src={buyer.profilePictureUrl}
                          alt={buyer.nickname}
                          className="w-full h-full rounded-full object-cover bg-slate-800"
                          referrerPolicy="no-referrer"
                          onError={(e) => ((e.target as HTMLElement).style.display = 'none')}
                        />
                      ) : (
                        <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-slate-400">
                          {idx + 1}
                        </div>
                      )}
                    </div>
                    <span className="absolute -bottom-1 -right-1 text-[11px] leading-none drop-shadow">
                      {medal}
                    </span>
                  </div>

                  {/* Info */}
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] font-semibold text-white truncate font-['Prompt'] leading-tight">
                      {buyer ? buyer.nickname : 'รอผู้สั่ง...'}
                    </div>
                    <div className="text-[11px] font-black font-mono tabular-nums leading-tight">
                      <span className={colorCls.split(' ').pop()}>
                        {buyer ? buyer.totalQuantity.toLocaleString() : '0'}
                      </span>
                      <span className="text-[9px] text-slate-400 font-normal ml-0.5">ไม้</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center: Live Key Metrics (2 Cols on LG) */}
        <div className="lg:col-span-2 flex lg:flex-col justify-around bg-slate-950/70 border border-slate-800/80 rounded-xl p-2 gap-1 text-center font-['Prompt']">
          <div className="flex flex-col items-center">
            <span className="text-[10px] text-slate-400">ยอดสั่งรวม</span>
            <span className="text-sm font-black text-amber-400 font-mono tabular-nums">
              {totalOrdered.toLocaleString()} <span className="text-[10px] text-slate-400 font-normal">ไม้</span>
            </span>
          </div>
          <div className="hidden lg:block w-full h-[1px] bg-slate-800" />
          <div className="flex flex-col items-center">
            <span className="text-[10px] text-slate-400">ย่างไว้รอลูกค้า</span>
            <span className="text-sm font-black text-yellow-300 font-mono tabular-nums">
              {readyWarmSkewers.toLocaleString()} <span className="text-[10px] text-slate-400 font-normal">ไม้</span>
            </span>
          </div>
        </div>

        {/* Right Side: Top 3 Helpers (5 Cols on LG) */}
        <div className="lg:col-span-5 flex flex-col gap-1.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 font-['Prompt']">
              <span>👨‍🍳</span>
              <span>ยอดผู้ช่วยย่างสูงสุด (Top 3)</span>
            </div>
            <span className="text-[11px] text-slate-400 font-['Prompt']">ช่วยย่างสะสม</span>
          </div>

          <div className="grid grid-cols-3 gap-1.5">
            {helpersTop3.map((helper, idx) => {
              const medal = medals[idx];
              const colorCls = helperMedalColors[idx];

              return (
                <div
                  key={idx}
                  className={`p-1.5 rounded-xl border bg-slate-950/60 flex items-center gap-2 min-w-0 transition-colors ${
                    helper
                      ? 'border-emerald-500/30 hover:border-emerald-500/50'
                      : 'border-slate-800/80 opacity-60'
                  }`}
                >
                  {/* Medal & Avatar */}
                  <div className="relative shrink-0">
                    <div className="w-8 h-8 rounded-full p-0.5 bg-gradient-to-tr from-emerald-400 to-teal-500">
                      {helper?.profilePictureUrl ? (
                        <img
                          src={helper.profilePictureUrl}
                          alt={helper.nickname}
                          className="w-full h-full rounded-full object-cover bg-slate-800"
                          referrerPolicy="no-referrer"
                          onError={(e) => ((e.target as HTMLElement).style.display = 'none')}
                        />
                      ) : (
                        <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-slate-400">
                          {idx + 1}
                        </div>
                      )}
                    </div>
                    <span className="absolute -bottom-1 -right-1 text-[11px] leading-none drop-shadow">
                      {medal}
                    </span>
                  </div>

                  {/* Info */}
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] font-semibold text-white truncate font-['Prompt'] leading-tight">
                      {helper ? helper.nickname : 'รอผู้ช่วย...'}
                    </div>
                    <div className="text-[11px] font-black font-mono tabular-nums leading-tight">
                      <span className={colorCls.split(' ').pop()}>
                        {helper ? helper.totalQuantity.toLocaleString() : '0'}
                      </span>
                      <span className="text-[9px] text-slate-400 font-normal ml-0.5">ไม้</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
