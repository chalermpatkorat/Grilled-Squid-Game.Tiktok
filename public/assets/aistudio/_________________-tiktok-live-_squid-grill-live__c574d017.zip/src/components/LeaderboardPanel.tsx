import React, { useState } from 'react';
import { LeaderboardEntry } from '../types/game';

interface LeaderboardPanelProps {
  topBuyers: LeaderboardEntry[];
  topHelpers: LeaderboardEntry[];
  totalOrdered: number;
  totalGrilled: number;
  totalLikes: number;
  totalRevenueEstimate: number;
}

export const LeaderboardPanel: React.FC<LeaderboardPanelProps> = ({
  topBuyers,
  topHelpers,
  totalOrdered,
  totalGrilled,
  totalLikes,
  totalRevenueEstimate,
}) => {
  const [activeTab, setActiveTab] = useState<'buyers' | 'helpers'>('buyers');

  const currentList = activeTab === 'buyers' ? topBuyers : topHelpers;
  const unitLabel = activeTab === 'buyers' ? 'ไม้ที่สั่ง' : 'ไม้ที่ช่วยย่าง';

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col gap-4">
      {/* 1. Header & Segmented Tab Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xl">📊</span>
          <h3 className="text-base font-bold text-white tracking-wide font-['Prompt']">
            กระดานผู้นำยอดขายแบบเรียลไทม์
          </h3>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-1 p-1 bg-slate-800/80 rounded-xl border border-slate-700">
          <button
            onClick={() => setActiveTab('buyers')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors font-['Prompt'] ${
              activeTab === 'buyers'
                ? 'bg-amber-500 text-stone-950 shadow'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            🏆 ลูกค้าสั่งซื้อสูงสุด ({topBuyers.length})
          </button>
          <button
            onClick={() => setActiveTab('helpers')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors font-['Prompt'] ${
              activeTab === 'helpers'
                ? 'bg-emerald-500 text-stone-950 shadow'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            👨‍🍳 ยอดช่วยย่างสูงสุด ({topHelpers.length})
          </button>
        </div>
      </div>

      {/* 2. Key Performance Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-slate-800/60 border border-slate-700/60 p-3 rounded-xl flex flex-col">
          <span className="text-xs text-slate-400 font-['Prompt']">ยอดสั่งปลาหมึกรวม</span>
          <span className="text-xl sm:text-2xl font-black text-amber-400 font-mono tabular-nums mt-0.5">
            {totalOrdered.toLocaleString()} <span className="text-xs font-normal text-slate-400">ไม้</span>
          </span>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 p-3 rounded-xl flex flex-col">
          <span className="text-xs text-slate-400 font-['Prompt']">ยอดช่วยย่างเสร็จ</span>
          <span className="text-xl sm:text-2xl font-black text-emerald-400 font-mono tabular-nums mt-0.5">
            {totalGrilled.toLocaleString()} <span className="text-xs font-normal text-slate-400">ไม้</span>
          </span>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 p-3 rounded-xl flex flex-col">
          <span className="text-xs text-slate-400 font-['Prompt']">เคาะจอเคาะใจรวม</span>
          <span className="text-xl sm:text-2xl font-black text-pink-400 font-mono tabular-nums mt-0.5">
            {totalLikes.toLocaleString()} <span className="text-xs font-normal text-slate-400">ใจ</span>
          </span>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/60 p-3 rounded-xl flex flex-col">
          <span className="text-xs text-slate-400 font-['Prompt']">ยอดขายรวมประมาณการ</span>
          <span className="text-xl sm:text-2xl font-black text-yellow-300 font-mono tabular-nums mt-0.5">
            {totalRevenueEstimate.toLocaleString()} <span className="text-xs font-normal text-slate-400">บาท</span>
          </span>
        </div>
      </div>

      {/* 3. Leaderboard List */}
      <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl overflow-hidden">
        {currentList.length === 0 ? (
          <div className="py-10 text-center text-slate-500 font-['Prompt'] text-sm flex flex-col items-center gap-2">
            <span className="text-2xl">⏳</span>
            <span>ยังไม่มีข้อมูลในกระดานนี้ รอคนดูส่งของขวัญเข้ามาในไลฟ์...</span>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/60 max-h-[300px] overflow-y-auto">
            {currentList.map((entry, index) => {
              const rank = index + 1;
              const isTop1 = rank === 1;
              const isTop2 = rank === 2;
              const isTop3 = rank === 3;

              return (
                <div
                  key={entry.uniqueId}
                  className={`px-3 py-2.5 flex items-center justify-between gap-3 transition-colors ${
                    isTop1
                      ? 'bg-amber-500/10 hover:bg-amber-500/15'
                      : isTop2
                      ? 'bg-slate-700/20 hover:bg-slate-700/30'
                      : isTop3
                      ? 'bg-amber-900/10 hover:bg-amber-900/20'
                      : 'hover:bg-slate-800/30'
                  }`}
                >
                  {/* Left: Rank Badge + Avatar + Names */}
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Rank Indicator */}
                    <div className="w-7 text-center font-black font-mono">
                      {isTop1 ? (
                        <span className="text-xl drop-shadow">🥇</span>
                      ) : isTop2 ? (
                        <span className="text-xl drop-shadow">🥈</span>
                      ) : isTop3 ? (
                        <span className="text-xl drop-shadow">🥉</span>
                      ) : (
                        <span className="text-sm text-slate-500">{rank}</span>
                      )}
                    </div>

                    {/* TikTok Circular Avatar */}
                    <div className="relative shrink-0">
                      <div
                        className={`w-10 h-10 rounded-full p-0.5 ${
                          isTop1
                            ? 'bg-gradient-to-tr from-yellow-400 to-amber-600 shadow-md shadow-yellow-500/20'
                            : 'bg-slate-700'
                        }`}
                      >
                        {entry.profilePictureUrl ? (
                          <img
                            src={entry.profilePictureUrl}
                            alt={entry.nickname}
                            className="w-full h-full rounded-full object-cover bg-slate-800"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                        ) : (
                          <div className="w-full h-full rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white">
                            {entry.nickname.slice(0, 2).toUpperCase()}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Nickname & Handle */}
                    <div className="min-w-0 flex flex-col">
                      <span className="text-sm font-semibold text-white truncate font-['Prompt']">
                        {entry.nickname}
                      </span>
                      <span className="text-[11px] text-slate-400 truncate font-mono">
                        @{entry.uniqueId}
                      </span>
                    </div>
                  </div>

                  {/* Right: Skewer Count */}
                  <div className="text-right shrink-0">
                    <span
                      className={`text-base font-black font-mono tabular-nums ${
                        isTop1
                          ? 'text-yellow-400'
                          : activeTab === 'buyers'
                          ? 'text-amber-300'
                          : 'text-emerald-300'
                      }`}
                    >
                      {entry.totalQuantity.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-400 font-['Prompt'] ml-1">
                      {unitLabel}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
