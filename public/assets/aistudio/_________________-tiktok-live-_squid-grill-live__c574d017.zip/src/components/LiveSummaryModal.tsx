import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { LiveStats, LeaderboardEntry } from '../types/game';

interface LiveSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: LiveStats;
  topBuyer: LeaderboardEntry | null;
  topHelper: LeaderboardEntry | null;
  onResetSession: () => void;
}

export const LiveSummaryModal: React.FC<LiveSummaryModalProps> = ({
  isOpen,
  onClose,
  stats,
  topBuyer,
  topHelper,
  onResetSession,
}) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Fire celebratory confetti!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {}
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Format session duration
  const durationMs = Date.now() - stats.streamStartTime;
  const minutes = Math.floor(durationMs / 60000);
  const seconds = Math.floor((durationMs % 60000) / 1000);
  const durationText = `${minutes} นาที ${seconds} วินาที`;

  // Summary text for clipboard
  const summaryText = `🎉 สรุปยอดขายปลาหมึกย่าง TikTok Live ประจำรอบ!
⏱️ ระยะเวลาไลฟ์: ${durationText}
🦑 ยอดสั่งปลาหมึกรวม: ${stats.totalSkewersOrdered.toLocaleString()} ไม้
🔥 ยอดช่วยย่างปลาหมึก: ${stats.totalSkewersGrilled.toLocaleString()} ไม้
❤️ ยอดเคาะใจรวม: ${stats.totalLikesReceived.toLocaleString()} ใจ
💰 รายได้รวมประมาณการ: ${stats.totalRevenueEstimate.toLocaleString()} บาท
👑 MVP สายเปย์ (สั่งเยอะสุด): ${topBuyer ? `${topBuyer.nickname} (@${topBuyer.uniqueId}) ${topBuyer.totalQuantity} ไม้` : '-'}
👨‍🍳 MVP ยอดเชฟ (ช่วยย่างเยอะสุด): ${topHelper ? `${topHelper.nickname} (@${topHelper.uniqueId}) ${topHelper.totalQuantity} ไม้` : '-'}
ขอบคุณทุกของขวัญและทุกกำลังใจจากทุกคนในไลฟ์มากๆ ครับ/ค่ะ! ❤️✨`;

  const handleCopySummary = () => {
    navigator.clipboard.writeText(summaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-amber-500/10 text-white my-8">
        {/* Header Icon & Title */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-400 to-orange-500 text-3xl shadow-lg shadow-orange-500/30 mb-3">
            🎉
          </div>
          <h2 className="text-2xl font-black text-white font-['Mali']">
            สรุปยอดขายปลาหมึกย่าง ปิดไลฟ์สด!
          </h2>
          <p className="text-xs text-amber-300 font-['Prompt'] mt-1">
            ระยะเวลาเปิดร้านไลฟ์สด: <span className="font-mono font-bold text-white">{durationText}</span>
          </p>
        </div>

        {/* 4 Big Summary Cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-slate-800/80 border border-slate-700/80 p-3.5 rounded-2xl flex flex-col">
            <span className="text-xs text-slate-400 font-['Prompt']">🦑 ยอดสั่งปลาหมึกทั้งหมด</span>
            <span className="text-2xl sm:text-3xl font-black text-amber-400 font-mono tabular-nums mt-1">
              {stats.totalSkewersOrdered.toLocaleString()} <span className="text-xs font-normal text-slate-400">ไม้</span>
            </span>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 p-3.5 rounded-2xl flex flex-col">
            <span className="text-xs text-slate-400 font-['Prompt']">🔥 ยอดช่วยย่างทั้งหมด</span>
            <span className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono tabular-nums mt-1">
              {stats.totalSkewersGrilled.toLocaleString()} <span className="text-xs font-normal text-slate-400">ไม้</span>
            </span>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 p-3.5 rounded-2xl flex flex-col">
            <span className="text-xs text-slate-400 font-['Prompt']">❤️ ยอดเคาะใจจากผู้ชม</span>
            <span className="text-2xl sm:text-3xl font-black text-pink-400 font-mono tabular-nums mt-1">
              {stats.totalLikesReceived.toLocaleString()} <span className="text-xs font-normal text-slate-400">ใจ</span>
            </span>
          </div>

          <div className="bg-slate-800/80 border border-slate-700/80 p-3.5 rounded-2xl flex flex-col">
            <span className="text-xs text-slate-400 font-['Prompt']">💰 รายได้รวมประมาณการ</span>
            <span className="text-2xl sm:text-3xl font-black text-yellow-300 font-mono tabular-nums mt-1">
              {stats.totalRevenueEstimate.toLocaleString()} <span className="text-xs font-normal text-slate-400">บาท</span>
            </span>
          </div>
        </div>

        {/* MVP Spotlight: Top Buyer & Top Helper */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          {/* Top Customer */}
          <div className="bg-gradient-to-b from-amber-950/40 to-slate-900 border border-amber-500/30 p-3.5 rounded-2xl flex items-center gap-3">
            <div className="relative shrink-0">
              <div className="w-12 h-12 rounded-full p-0.5 bg-gradient-to-tr from-yellow-400 to-amber-500 shadow">
                {topBuyer?.profilePictureUrl ? (
                  <img
                    src={topBuyer.profilePictureUrl}
                    alt={topBuyer.nickname}
                    className="w-full h-full rounded-full object-cover bg-slate-800"
                    referrerPolicy="no-referrer"
                    onError={(e) => ((e.target as HTMLElement).style.display = 'none')}
                  />
                ) : (
                  <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center font-bold text-amber-300 text-sm">
                    👑
                  </div>
                )}
              </div>
              <span className="absolute -bottom-1 -right-1 text-xs">🥇</span>
            </div>
            <div className="min-w-0">
              <span className="text-[10px] text-amber-400 font-bold uppercase font-['Prompt']">
                👑 MVP ลูกค้าสายเปย์
              </span>
              <div className="text-sm font-bold text-white truncate font-['Prompt']">
                {topBuyer ? topBuyer.nickname : 'ยังไม่มีข้อมูล'}
              </div>
              <div className="text-xs text-amber-300 font-mono">
                {topBuyer ? `${topBuyer.totalQuantity.toLocaleString()} ไม้` : '-'}
              </div>
            </div>
          </div>

          {/* Top Helper */}
          <div className="bg-gradient-to-b from-emerald-950/40 to-slate-900 border border-emerald-500/30 p-3.5 rounded-2xl flex items-center gap-3">
            <div className="relative shrink-0">
              <div className="w-12 h-12 rounded-full p-0.5 bg-gradient-to-tr from-emerald-400 to-teal-500 shadow">
                {topHelper?.profilePictureUrl ? (
                  <img
                    src={topHelper.profilePictureUrl}
                    alt={topHelper.nickname}
                    className="w-full h-full rounded-full object-cover bg-slate-800"
                    referrerPolicy="no-referrer"
                    onError={(e) => ((e.target as HTMLElement).style.display = 'none')}
                  />
                ) : (
                  <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center font-bold text-emerald-300 text-sm">
                    👨‍🍳
                  </div>
                )}
              </div>
              <span className="absolute -bottom-1 -right-1 text-xs">🔥</span>
            </div>
            <div className="min-w-0">
              <span className="text-[10px] text-emerald-400 font-bold uppercase font-['Prompt']">
                👨‍🍳 MVP ยอดเชฟช่วยย่าง
              </span>
              <div className="text-sm font-bold text-white truncate font-['Prompt']">
                {topHelper ? topHelper.nickname : 'ยังไม่มีข้อมูล'}
              </div>
              <div className="text-xs text-emerald-300 font-mono">
                {topHelper ? `${topHelper.totalQuantity.toLocaleString()} ไม้` : '-'}
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          <button
            onClick={handleCopySummary}
            className="flex-1 py-3 px-4 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-stone-950 font-bold rounded-xl text-sm font-['Prompt'] transition flex items-center justify-center gap-2 shadow-lg"
          >
            <span>📋</span>
            <span>{copied ? 'คัดลอกสรุปสำเร็จแล้ว!' : 'คัดลอกสรุปยอดส่งโพสต์'}</span>
          </button>

          <button
            onClick={() => {
              if (confirm('คุณต้องการรีเซ็ตสถิติเพื่อเริ่มเปิดร้านไลฟ์สดรอบใหม่ใช่หรือไม่?')) {
                onResetSession();
                onClose();
              }
            }}
            className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-medium rounded-xl text-xs font-['Prompt'] transition"
          >
            เริ่มไลฟ์รอบใหม่ (รีเซ็ต)
          </button>

          <button
            onClick={onClose}
            className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-medium rounded-xl text-xs font-['Prompt'] transition"
          >
            กลับสู่เกม
          </button>
        </div>
      </div>
    </div>
  );
};
