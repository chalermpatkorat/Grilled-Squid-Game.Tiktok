// Web Audio API Synthesizer & Web Speech API Thai TTS for Squid Grill Game

class SoundManager {
  private audioCtx: AudioContext | null = null;
  private sizzleNode: AudioNode | null = null;
  private sizzleGain: GainNode | null = null;
  private bgmOscillators: OscillatorNode[] = [];
  private bgmGain: GainNode | null = null;
  private isBgmPlaying: boolean = false;
  private bgmTimer: any = null;
  private isMuted: boolean = false;
  private isTtsEnabled: boolean = true;
  private speechQueue: string[] = [];
  private isSpeaking: boolean = false;

  constructor() {
    // AudioContext will be initialized on first user interaction
  }

  private initContext() {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.bgmGain) {
      this.bgmGain.gain.setValueAtTime(muted ? 0 : 0.12, this.audioCtx?.currentTime || 0);
    }
    if (this.sizzleGain) {
      this.sizzleGain.gain.setValueAtTime(muted ? 0 : 0.08, this.audioCtx?.currentTime || 0);
    }
  }

  public setTtsEnabled(enabled: boolean) {
    this.isTtsEnabled = enabled;
    if (!enabled && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.speechQueue = [];
      this.isSpeaking = false;
    }
  }

  // 1. Synthesize Realistic BBQ Grill Sizzle
  public startGrillSizzle() {
    this.initContext();
    if (!this.audioCtx || this.sizzleNode) return;

    try {
      // Create white noise buffer
      const bufferSize = this.audioCtx.sampleRate * 2;
      const noiseBuffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.audioCtx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      // Bandpass filter to sculpt sizzling sound
      const filter = this.audioCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(3200, this.audioCtx.currentTime);
      filter.Q.setValueAtTime(2.5, this.audioCtx.currentTime);

      this.sizzleGain = this.audioCtx.createGain();
      this.sizzleGain.gain.setValueAtTime(this.isMuted ? 0 : 0.06, this.audioCtx.currentTime);

      whiteNoise.connect(filter);
      filter.connect(this.sizzleGain);
      this.sizzleGain.connect(this.audioCtx.destination);

      whiteNoise.start(0);
      this.sizzleNode = whiteNoise;
    } catch (e) {
      console.warn('Audio sizzle init error', e);
    }
  }

  public stopGrillSizzle() {
    if (this.sizzleNode) {
      try {
        (this.sizzleNode as AudioScheduledSourceNode).stop();
        this.sizzleNode.disconnect();
      } catch (e) {}
      this.sizzleNode = null;
    }
  }

  // 2. Play Order Ding / Bell
  public playOrderBell() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    // Harmonic bell chord (C6, E6, G6)
    const freqs = [1046.5, 1318.5, 1567.98];
    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.04);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.18 / (idx + 1), now + idx * 0.04 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8 + idx * 0.1);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.04);
      osc.stop(now + 1.2);
    });
  }

  // 3. Play Skewer Flip & Sizzle splash
  public playFlipSound() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(580, now + 0.08);
    osc.frequency.exponentialRampToValueAtTime(140, now + 0.2);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.25);
  }

  // 4. Play Cash / Serve Cha-Ching sound
  public playServeSound() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    const notes = [1318.51, 1567.98, 2093.0]; // E6, G6, C7
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.08);

      gain.gain.setValueAtTime(0.15, now + i * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + i * 0.08);
      osc.stop(now + i * 0.08 + 0.45);
    });
  }

  // 4.1 Play Skewer Cooked Ding
  public playCookedDing() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1760, now); // A6 bright ping
    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.4);
  }

  // 4.2 Play Sauce Ladle & Plate clink
  public playLadleSauce() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    // Soft Ceramic clink + liquid splash
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(880, now);
    osc.frequency.exponentialRampToValueAtTime(440, now + 0.1);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.22);
  }

  // 5. Play Helper Boost / Cheer sound
  public playHelperCheer() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    const chord = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    chord.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.05);

      gain.gain.setValueAtTime(0.12, now + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.05);
      osc.stop(now + 0.8);
    });
  }

  // 6. Play Gentle Cute BGM (Acoustic pentatonic cute street melody)
  public toggleBgm(play?: boolean) {
    this.initContext();
    if (!this.audioCtx) return;

    const targetPlay = play !== undefined ? play : !this.isBgmPlaying;
    if (!targetPlay) {
      if (this.bgmTimer) {
        clearInterval(this.bgmTimer);
        this.bgmTimer = null;
      }
      this.isBgmPlaying = false;
      return;
    }

    if (this.isBgmPlaying) return;
    this.isBgmPlaying = true;

    // Cute Pentatonic Thai/Asian night food market scale: C4, D4, E4, G4, A4, C5, D5, E5
    const scale = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33, 659.25];
    const bassScale = [130.81, 146.83, 164.81, 196.0];
    let noteIndex = 0;

    const playCuteNote = () => {
      if (!this.isBgmPlaying || !this.audioCtx || this.isMuted) return;
      const ctx = this.audioCtx;
      const now = ctx.currentTime;

      // Melody note (warm soft marimba tone)
      const freq = scale[noteIndex % scale.length];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(0.04, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.4);

      // Bass note on downbeats
      if (noteIndex % 4 === 0) {
        const bassOsc = ctx.createOscillator();
        const bassGain = ctx.createGain();
        const bassFreq = bassScale[(noteIndex / 4) % bassScale.length];

        bassOsc.type = 'triangle';
        bassOsc.frequency.setValueAtTime(bassFreq, now);

        bassGain.gain.setValueAtTime(0.06, now);
        bassGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.6);

        bassOsc.connect(bassGain);
        bassGain.connect(ctx.destination);

        bassOsc.start(now);
        bassOsc.stop(now + 0.65);
      }

      noteIndex = (noteIndex + 1) % 32;
    };

    this.bgmTimer = setInterval(playCuteNote, 280);
  }

  // 7. Thai Text-To-Speech (TTS)
  public speakThai(text: string) {
    if (!this.isTtsEnabled) return;
    if (!('speechSynthesis' in window)) return;

    this.speechQueue.push(text);
    this.processSpeechQueue();
  }

  private processSpeechQueue() {
    if (this.isSpeaking || this.speechQueue.length === 0) return;
    const textToSpeak = this.speechQueue.shift();
    if (!textToSpeak) return;

    this.isSpeaking = true;
    try {
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = 'th-TH';
      utterance.rate = 1.05; // slightly cheerful & upbeat
      utterance.pitch = 1.1;

      // Try finding Thai voice
      const voices = window.speechSynthesis.getVoices();
      const thaiVoice = voices.find((v) => v.lang.includes('th') || v.name.toLowerCase().includes('thai'));
      if (thaiVoice) {
        utterance.voice = thaiVoice;
      }

      utterance.onend = () => {
        this.isSpeaking = false;
        setTimeout(() => this.processSpeechQueue(), 250);
      };

      utterance.onerror = () => {
        this.isSpeaking = false;
        setTimeout(() => this.processSpeechQueue(), 250);
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech error', e);
      this.isSpeaking = false;
    }
  }

  // 8. Device Vibration Alert
  public triggerVibration(pattern: number[] = [100, 60, 140, 60, 200]) {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch (e) {
        // ignore if not supported or disabled
      }
    }
  }
}

export const soundManager = new SoundManager();
