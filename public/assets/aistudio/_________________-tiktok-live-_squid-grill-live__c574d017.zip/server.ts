import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
// @ts-ignore - legacy provides flattened event payload
import { WebcastPushConnection } from 'tiktok-live-connector/legacy';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = 3000;

app.use(express.json());

// In-memory SSE clients for real-time live events
interface SSEClient {
  id: number;
  res: express.Response;
}

let sseClients: SSEClient[] = [];
let clientIdCounter = 0;

function broadcastEvent(type: string, data: any) {
  const payload = JSON.stringify({ type, data, timestamp: Date.now() });
  sseClients.forEach((client) => {
    try {
      client.res.write(`data: ${payload}\n\n`);
    } catch (e) {
      // client may be closed
    }
  });
}

// Current TikTok Live Connection state
let tiktokLiveConnection: any = null;
let currentUsername: string = '';
let connectionStatus: 'disconnected' | 'connecting' | 'connected' | 'error' = 'disconnected';
let connectionError: string = '';
let roomInfo: any = null;

// Like accumulator for "100 likes = 1 grilled skewer"
let accumulatedLikes: { [userId: string]: { username: string; nickname: string; avatar: string; count: number } } = {};

function processLikes(user: any, likeCount: number) {
  const uid = user.userId || user.uniqueId || 'unknown';
  if (!accumulatedLikes[uid]) {
    accumulatedLikes[uid] = {
      username: user.uniqueId || 'viewer',
      nickname: user.nickname || user.uniqueId || 'ผู้ชม',
      avatar: user.profilePictureUrl || '',
      count: 0,
    };
  }
  accumulatedLikes[uid].count += likeCount;

  // Check if reached multiples of 100
  if (accumulatedLikes[uid].count >= 100) {
    const skewersToGrill = Math.floor(accumulatedLikes[uid].count / 100);
    accumulatedLikes[uid].count = accumulatedLikes[uid].count % 100;

    broadcastEvent('helper_action', {
      source: 'like',
      userId: uid,
      uniqueId: accumulatedLikes[uid].username,
      nickname: accumulatedLikes[uid].nickname,
      profilePictureUrl: accumulatedLikes[uid].avatar,
      grillCount: skewersToGrill,
      description: `เคาะจอครบ 100 ใจ ช่วยย่าง ${skewersToGrill} ไม้!`,
    });
  }
}

// Gift matcher logic based on user specification:
// 1. ดอกกุหลาบ 1 ดอก = สั่ง 1 ไม้
// 2. หัวใจนิ้ว 1 อัน = สั่ง 5 ไม้
// 3. น้ำหอม 1 อัน = สั่ง 10 ไม้
// 4. โดนัท 1 อัน = สั่ง 20 ไม้
// 5. หมวกกับหนวด 1 อัน = สุ่มสั่ง 20 - 100 ไม้
// 6. ส่งของขวัญเยี่ยมสุดๆ = ช่วยย่าง 2 ไม้
// 7. ส่งไดโนเสาร์จิ๋ว = ช่วยย่าง 20 ไม้
// 8. ส่งหมีมีชคา 1 ตัว = ช่วยย่าง 100 ไม้
function matchGiftToGameAction(giftData: any) {
  const giftName = (giftData.giftName || '').toLowerCase();
  const giftId = giftData.giftId;
  const repeatCount = giftData.repeatCount || 1;
  const diamonds = giftData.diamondCount || 1;
  const nickname = giftData.nickname || giftData.uniqueId || 'ลูกค้า';
  const uniqueId = giftData.uniqueId || 'viewer';
  const profilePictureUrl = giftData.profilePictureUrl || '';

  // 1. Order gifts
  if (giftName.includes('rose') || giftName.includes('กุหลาบ')) {
    const skewers = 1 * repeatCount;
    return {
      action: 'order',
      skewers,
      giftName: 'ดอกกุหลาบ 🌹',
      nickname,
      uniqueId,
      profilePictureUrl,
      diamonds: diamonds * repeatCount,
    };
  }

  if (giftName.includes('finger heart') || giftName.includes('หัวใจนิ้ว') || giftName.includes('heart finger')) {
    const skewers = 5 * repeatCount;
    return {
      action: 'order',
      skewers,
      giftName: 'หัวใจนิ้ว 🫰',
      nickname,
      uniqueId,
      profilePictureUrl,
      diamonds: diamonds * repeatCount,
    };
  }

  if (giftName.includes('perfume') || giftName.includes('น้ำหอม')) {
    const skewers = 10 * repeatCount;
    return {
      action: 'order',
      skewers,
      giftName: 'น้ำหอม 🧴',
      nickname,
      uniqueId,
      profilePictureUrl,
      diamonds: diamonds * repeatCount,
    };
  }

  if (giftName.includes('doughnut') || giftName.includes('donut') || giftName.includes('โดนัท')) {
    const skewers = 20 * repeatCount;
    return {
      action: 'order',
      skewers,
      giftName: 'โดนัท 🍩',
      nickname,
      uniqueId,
      profilePictureUrl,
      diamonds: diamonds * repeatCount,
    };
  }

  if (
    giftName.includes('cap') ||
    giftName.includes('mustache') ||
    giftName.includes('หมวก') ||
    giftName.includes('หนวด')
  ) {
    // Random 20 - 100 skewers per unit
    let totalRandom = 0;
    for (let i = 0; i < repeatCount; i++) {
      totalRandom += Math.floor(Math.random() * 81) + 20; // 20 to 100
    }
    return {
      action: 'order',
      skewers: totalRandom,
      isRandom: true,
      giftName: 'หมวกกับหนวด 🎩🥸 (สุ่มแจ็คพอต!)',
      nickname,
      uniqueId,
      profilePictureUrl,
      diamonds: diamonds * repeatCount,
    };
  }

  // 2. Helper gifts
  if (giftName.includes('very good') || giftName.includes('เยี่ยมสุด') || giftName.includes('เยี่ยม')) {
    const grillCount = 2 * repeatCount;
    return {
      action: 'helper',
      grillCount,
      giftName: 'เยี่ยมสุดๆ 👍✨',
      nickname,
      uniqueId,
      profilePictureUrl,
      diamonds: diamonds * repeatCount,
    };
  }

  if (giftName.includes('dino') || giftName.includes('ไดโนเสาร์') || giftName.includes('dinosaur')) {
    const grillCount = 20 * repeatCount;
    return {
      action: 'helper',
      grillCount,
      giftName: 'ไดโนเสาร์จิ๋ว 🦖🔥',
      nickname,
      uniqueId,
      profilePictureUrl,
      diamonds: diamonds * repeatCount,
    };
  }

  if (giftName.includes('mishka') || giftName.includes('หมี') || giftName.includes('bear')) {
    const grillCount = 100 * repeatCount;
    return {
      action: 'helper',
      grillCount,
      giftName: 'หมีมีชคา 🐻🎉',
      nickname,
      uniqueId,
      profilePictureUrl,
      diamonds: diamonds * repeatCount,
    };
  }

  // Fallback generic gift:
  // If low diamond -> order proportional (1 diamond = 1 skewer)
  // If high diamond -> major order
  const calculatedSkewers = Math.max(1, Math.round(diamonds * repeatCount));
  return {
    action: 'order',
    skewers: calculatedSkewers,
    giftName: giftData.giftName || 'ของขวัญ 🎁',
    nickname,
    uniqueId,
    profilePictureUrl,
    diamonds: diamonds * repeatCount,
  };
}

// SSE stream endpoint
app.get('/api/tiktok/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const clientId = ++clientIdCounter;
  sseClients.push({ id: clientId, res });

  // Send initial connection state
  res.write(
    `data: ${JSON.stringify({
      type: 'status',
      data: {
        status: connectionStatus,
        username: currentUsername,
        roomInfo,
        error: connectionError,
      },
      timestamp: Date.now(),
    })}\n\n`
  );

  req.on('close', () => {
    sseClients = sseClients.filter((c) => c.id !== clientId);
  });
});

// TikTok Connect endpoint
app.post('/api/tiktok/connect', async (req, res) => {
  let { username } = req.body;
  if (!username) {
    return res.status(400).json({ error: 'Username is required' });
  }

  username = username.replace(/^@/, '').trim();
  currentUsername = username;
  connectionStatus = 'connecting';
  connectionError = '';
  broadcastEvent('status', { status: 'connecting', username });

  try {
    if (tiktokLiveConnection) {
      try {
        tiktokLiveConnection.disconnect();
      } catch (e) {
        // ignore
      }
      tiktokLiveConnection = null;
    }

    tiktokLiveConnection = new WebcastPushConnection(username, {
      processInitialData: false,
      enableExtendedGiftInfo: true,
      requestPollingIntervalMs: 1000,
      clientParams: {
        app_language: 'th-TH',
        device_platform: 'web',
      },
    } as any);

    const state = await tiktokLiveConnection.connect();
    connectionStatus = 'connected';
    roomInfo = {
      roomId: state?.roomId,
      roomInfo: state?.roomInfo,
    };

    broadcastEvent('status', {
      status: 'connected',
      username,
      roomInfo,
    });

    // Event listeners
    tiktokLiveConnection.on('gift', (data: any) => {
      // Avoid duplicated combo streaks
      if (data.giftType === 1 && !data.repeatEnd) {
        // combo in progress, we can either tally at end or count incremental
      }
      const mapped = matchGiftToGameAction(data);
      if (mapped.action === 'order') {
        broadcastEvent('order_action', mapped);
      } else if (mapped.action === 'helper') {
        broadcastEvent('helper_action', mapped);
      }
    });

    tiktokLiveConnection.on('like', (data: any) => {
      processLikes(data, data.likeCount || 1);
      broadcastEvent('like_pulse', {
        nickname: data.nickname || data.uniqueId || 'ผู้ชม',
        uniqueId: data.uniqueId || 'viewer',
        profilePictureUrl: data.profilePictureUrl || '',
        likeCount: data.likeCount || 1,
        totalLikes: data.totalLikeCount || 0,
      });
    });

    tiktokLiveConnection.on('chat', (data: any) => {
      broadcastEvent('chat_message', {
        uniqueId: data.uniqueId,
        nickname: data.nickname,
        comment: data.comment,
        profilePictureUrl: data.profilePictureUrl,
      });
    });

    tiktokLiveConnection.on('member', (data: any) => {
      broadcastEvent('member_join', {
        uniqueId: data.uniqueId,
        nickname: data.nickname,
        profilePictureUrl: data.profilePictureUrl,
      });
    });

    tiktokLiveConnection.on('disconnected', () => {
      connectionStatus = 'disconnected';
      broadcastEvent('status', { status: 'disconnected', username });
    });

    tiktokLiveConnection.on('streamEnd', () => {
      connectionStatus = 'disconnected';
      broadcastEvent('status', { status: 'disconnected', username, message: 'การไลฟ์สดสิ้นสุดลงแล้ว' });
    });

    return res.json({ success: true, username, roomId: state?.roomId });
  } catch (err: any) {
    console.error('TikTok Live Connect error:', err);
    connectionStatus = 'error';
    connectionError = err?.message || 'เชื่อมต่อ TikTok Live ไม่สำเร็จ กรุณาตรวจสอบว่ากำลังเปิดไลฟ์อยู่หรือไม่';
    broadcastEvent('status', {
      status: 'error',
      username,
      error: connectionError,
    });
    return res.status(500).json({
      error: connectionError,
      suggestion: 'สามารถใช้โหมดจำลอง (Simulator) ในเกมเพื่อทดสอบทุกระบบได้ทันที',
    });
  }
});

// TikTok Disconnect endpoint
app.post('/api/tiktok/disconnect', (req, res) => {
  if (tiktokLiveConnection) {
    try {
      tiktokLiveConnection.disconnect();
    } catch (e) {
      // ignore
    }
    tiktokLiveConnection = null;
  }
  connectionStatus = 'disconnected';
  broadcastEvent('status', { status: 'disconnected', username: currentUsername });
  res.json({ success: true });
});

// TikTok Status endpoint
app.get('/api/tiktok/status', (req, res) => {
  res.json({
    status: connectionStatus,
    username: currentUsername,
    roomInfo,
    error: connectionError,
    connectedClients: sseClients.length,
  });
});

// TikTok Simulation endpoint (Allows triggering gifts & likes directly from client UI or bot)
app.post('/api/tiktok/simulate', (req, res) => {
  const { giftType, nickname, uniqueId, profilePictureUrl, count, isLike } = req.body;

  if (isLike) {
    processLikes(
      {
        userId: uniqueId || 'sim_user',
        uniqueId: uniqueId || 'viewer',
        nickname: nickname || 'ผู้ชมสายเคาะ',
        profilePictureUrl: profilePictureUrl || '',
      },
      count || 100
    );
    broadcastEvent('like_pulse', {
      nickname: nickname || 'ผู้ชมสายเคาะ',
      uniqueId: uniqueId || 'viewer',
      profilePictureUrl: profilePictureUrl || '',
      likeCount: count || 100,
    });
    return res.json({ success: true });
  }

  const simulatedGift = {
    giftName: giftType,
    repeatCount: count || 1,
    diamondCount: 1,
    nickname: nickname || 'เพื่อนในไลฟ์',
    uniqueId: uniqueId || 'tiktok_friend',
    profilePictureUrl: profilePictureUrl || '',
  };

  const mapped = matchGiftToGameAction(simulatedGift);
  if (mapped.action === 'order') {
    broadcastEvent('order_action', mapped);
  } else if (mapped.action === 'helper') {
    broadcastEvent('helper_action', mapped);
  }

  res.json({ success: true, result: mapped });
});

// Mount Vite or serve static
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
